import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'results/dados_radiacao_processados/radiacao_anual_max_min.csv'

# Define o renderizador padrão para abrir no navegador
pio.renderers.default = 'browser'

def visualizar_radiacao_max_min_anuais():
    """
    Cria um gráfico de linha interativo com os dados anuais de radiação máxima e mínima.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'gerar_dados_radiacao_max_min.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)

    # --- Criação do Gráfico ---
    print("Gerando gráfico com Plotly...")
    fig = go.Figure()

    # Adiciona a linha de Radiação Máxima
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Radiacao_Maxima_kj_m2'],
        name='Radiação Máxima (kJ/m²)',
        mode='lines+markers+text',
        line=dict(color='orange'),
        hovertext=df['Mes_Maxima'],
        text=df['Mes_Maxima'],
        textposition='top center',
        textfont=dict(size=10, color='dimgray'),
        hovertemplate='<b>Ano</b>: %{x}<br><b>Máxima</b>: %{y:.2f} kJ/m²<br><b>Mês</b>: %{hovertext}<extra></extra>'
    ))

    # Adiciona a linha de Radiação Mínima
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Radiacao_Minima_kj_m2'],
        name='Radiação Mínima (kJ/m²)',
        mode='lines+markers+text',
        line=dict(color='skyblue'),
        hovertext=df['Mes_Minima'],
        text=df['Mes_Minima'],
        textposition='bottom center',
        textfont=dict(size=10, color='dimgray'),
        hovertemplate='<b>Ano</b>: %{x}<br><b>Mínima</b>: %{y:.2f} kJ/m²<br><b>Mês</b>: %{hovertext}<extra></extra>'
    ))

    # --- Customização do Layout ---
    fig.update_layout(
        title={'text': '<b>Evolução Anual da Radiação Solar Máxima e Mínima no Amazonas</b>', 'y':0.9, 'x':0.5, 'xanchor': 'center', 'yanchor': 'top'},
        xaxis_title='<b>Ano</b>',
        yaxis_title='<b>Radiação Média Mensal (kJ/m²)</b>',
        plot_bgcolor='white',
        font=dict(family="Arial, sans-serif", size=12, color="black"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    fig.update_xaxes(tickmode='linear', gridcolor='lightgray', linecolor='black')
    fig.update_yaxes(gridcolor='lightgray', linecolor='black')

    # --- Exibição do Gráfico ---
    print("Exibindo gráfico interativo. Uma nova aba será aberta no seu navegador.")
    fig.show()

if __name__ == '__main__':
    visualizar_radiacao_max_min_anuais()
