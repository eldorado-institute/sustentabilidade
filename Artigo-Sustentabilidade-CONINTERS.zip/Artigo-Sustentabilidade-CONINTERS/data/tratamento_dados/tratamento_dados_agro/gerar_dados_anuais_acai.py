import pandas as pd
import glob
import json
import os

# --- Configuração ---
# O script deve ser executado a partir da raiz do projeto.
# Caminho para os arquivos JSON de entrada
INPUT_PATH_PATTERN = 'cleaned_data/*.json'
# Diretório de saída para o arquivo CSV
OUTPUT_DIR = 'knowledge/dados_prod_agricola/'
# Nome do arquivo CSV de saída
OUTPUT_FILENAME = 'producao_agricola_anual_acai.csv'
# Produto de interesse
PRODUTO_ALVO = 'Açaí'

def processar_dados_acai():
    """
    Carrega dados de produção agrícola, filtra para o açaí,
    processa para manter os dados anuais por município e salva em um CSV.
    """
    # --- Carregamento dos Dados ---
    print(f"Procurando arquivos em: {INPUT_PATH_PATTERN}")
    files = glob.glob(INPUT_PATH_PATTERN)
    if not files:
        print(f"Nenhum arquivo JSON encontrado no padrão: {INPUT_PATH_PATTERN}")
        print("Verifique se o script está sendo executado da raiz do projeto.")
        return

    print(f"Encontrados {len(files)} arquivos. Carregando dados...")
    dados = []
    for file_path in files:
        with open(file_path, 'r', encoding='utf-8') as f:
            dados.extend(json.load(f))

    df = pd.DataFrame(dados)
    print("Dados carregados com sucesso.")

    # --- Pré-processamento e Filtragem ---
    # Converter a coluna de valor para numérico, tratando erros
    df['V'] = pd.to_numeric(df['V'], errors='coerce')

    # Filtrar para manter apenas os dados do produto de interesse (Açaí)
    df_acai = df[df['D2N'] == PRODUTO_ALVO].copy()

    if df_acai.empty:
        print(f"Nenhum dado encontrado para o produto '{PRODUTO_ALVO}'.")
        return

    print(f"Dados filtrados para o produto: '{PRODUTO_ALVO}'.")

    # --- Reestruturação dos Dados (Pivot) ---
    # O ano está na coluna 'D3N'.
    # Criar uma tabela onde cada linha representa um município em um ano específico,
    # e as colunas representam as diferentes variáveis da produção.
    print("Reestruturando dados para formato anual por município...")
    df_anual = df_acai.pivot_table(
        index=['D1N', 'D3N'],  # Agrupar por Município (D1N) e Ano (D3N)
        columns='D4N',         # As variáveis (D4N) se tornarão colunas
        values='V',            # Os valores virão da coluna 'V'
        aggfunc='first'        # Como cada combinação deve ser única, 'first' ou 'mean' funcionam
    ).reset_index()

    # --- Limpeza e Formatação Final ---
    df_anual.rename(columns={'D1N': 'Municipio', 'D3N': 'Ano'}, inplace=True)

    if 'Área plantada' in df_anual.columns:
        df_anual = df_anual.drop(columns=['Área plantada'])
        print("Coluna 'Área plantada' removida.")

    df_anual = df_anual.fillna(0)
    numeric_cols = df_anual.select_dtypes(include='number').columns
    df_anual[numeric_cols] = df_anual[numeric_cols].round(2) # Arredonda antes de formatar

    # Formata as colunas numéricas para o padrão brasileiro (ex: 1.234,56)
    # ATENÇÃO: Isso converte os números para texto (string).
    print("Formatando colunas numéricas para o padrão brasileiro...")
    for col in numeric_cols:
        # Evita formatar a coluna 'Ano' como um valor monetário
        if 'Ano' not in col:
            df_anual[col] = df_anual[col].apply(
                lambda x: f'{x:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
            )

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    output_path = os.path.join(OUTPUT_DIR, OUTPUT_FILENAME)

    df_anual.to_csv(output_path, index=False, encoding='utf-8-sig') # Salva o DataFrame com as strings formatadas
    print(f"\nArquivo '{OUTPUT_FILENAME}' salvo com sucesso em '{output_path}'.")
    print("\nVisualização das primeiras 5 linhas do resultado:")
    print(df_anual.head())

if __name__ == '__main__':
    processar_dados_acai()
