import pandas as pd
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'results/dados_radiacao_processados/radiacao_media_mensal.csv'
OUTPUT_DIR = 'results/dados_radiacao_processados'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'radiacao_media_anual.csv')

def calcular_media_anual_radiacao():
    """
    Lê os dados de radiação média mensal, calcula a média anual
    agregando todas as estações e salva em um novo CSV.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'dados_radiacao.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE, sep=';')

    # --- Limpeza e Conversão de Dados ---
    print("Convertendo colunas para formato numérico...")
    # Assegura que as colunas são do tipo correto
    df['ano'] = pd.to_numeric(df['ano'], errors='coerce')
    df['radiacao_media_kj_m2'] = pd.to_numeric(df['radiacao_media_kj_m2'], errors='coerce')
    df.dropna(subset=['ano', 'radiacao_media_kj_m2'], inplace=True)
    df['ano'] = df['ano'].astype(int)

    # --- Agregação dos Dados por Ano ---
    print("Agregando dados por ano para calcular a média e o desvio padrão da radiação...")
    # Agrupa por ano e calcula a média e o desvio padrão da radiação média mensal de todas as estações
    df_anual = df.groupby('ano')['radiacao_media_kj_m2'].agg(['mean', 'std']).reset_index()

    # Renomeia as colunas para maior clareza
    df_anual.rename(columns={
        'ano': 'Ano',
        'mean': 'Radiacao_Media_Anual_kj_m2',
        'std': 'Radiacao_Desvio_Padrao_Anual_kj_m2'
    }, inplace=True)

    # Preenche valores NaN no desvio padrão (caso haja apenas uma medição no ano) com 0
    df_anual['Radiacao_Desvio_Padrao_Anual_kj_m2'] = df_anual['Radiacao_Desvio_Padrao_Anual_kj_m2'].fillna(0)

    # Arredonda o resultado
    df_anual = df_anual.round(2)

    # --- Salvando o Resultado ---
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df_anual.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig')

    print(f"\nArquivo '{os.path.basename(OUTPUT_FILE)}' salvo com sucesso em '{OUTPUT_FILE}'.")
    print("\nVisualização do resultado:")
    print(df_anual.to_string(index=False))

if __name__ == '__main__':
    calcular_media_anual_radiacao()
