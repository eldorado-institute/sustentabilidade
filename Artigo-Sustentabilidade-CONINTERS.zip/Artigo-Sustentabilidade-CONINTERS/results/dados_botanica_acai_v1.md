**Dados Botânicos do Açaí**

**1. Pré-Produção**:

O item pré-produção trata de temas relacionados à importância socioeconômica da cultura do açaí bem como às características da espécie e relações com o meio ambiente.

**1.1. Importância Socioeconômica:**


**1.1.1. Mercado externo:**

Observa-se que o açaí lidera a economia da fruticultura, tendo o Estado do Pará o epicentro da produção e processamento. Em 2006, esse estado exportou 8 mil toneladas de polpa da fruta. A demanda por açaí foi estimada em 300 mil toneladas de polpa em 2006, podendo se estabilizar em 500 mil toneladas nos próximos 10 anos, mantendo um fluxo de exportação de 60 mil toneladas por ano e o restante para consumo no mercado brasileiro.

De 2004 a 2008, o Estado do Pará mostrou um crescimento constante na exportação de açaí, como é evidenciado pelo valor comercializado, que obteve um crescimento de US$ 1.982.791 em 2004 para US$ 20.738.868 em 2008, um aumento de 1.046%, embora a quantidade exportada tenha crescido apenas 560% no mesmo período. Isso ocorreu em decorrência do aumento do preço médio em cerca de 187% nesse intervalo, aumentando, assim, a lucratividade da exportação do produto. Para 2009, todos esses valores aumentaram, e o valor comercializado, a quantidade comercializada e o preço médio, no período de janeiro a julho de 2008 e 2009, revelaram aumentos de 47,05%, 41,21% e  4,16%, respectivamente.Os Estados Unidos são os principais importadores do açaí do Estado do Pará, com 92% da quantidade total em toneladas e do valor comercializado em 2008, equivalente a 7 t e US$ 19 milhões, respectivamente. Com isso, esse país ratifica o seu papel preponderante na exportação do açaí paraense, que experimentou um crescimento de 1.449% dos valores de importação no período de 2004 a 2008. Japão e Países Baixos ocupam as próximas posições, com cerca de 2,5% dos importadores cada. Embora os números do Reino Unido sejam baixos (0,56%  de participação no mercado), é possível observar que esse mercado parece estar em franca expansão, tendo sido observado, relativamente, o maior crescimento de valores (mais de 17.000%).
 
Para as estimativas de janeiro a julho de 2008 e 2009, no entanto, o único país que demonstrou aumento foram os Estados Unidos (valor 73,7% maior e 61,4% de toneladas a mais quando se comparam os dois períodos), enquanto Japão, Reino Unido, Suécia e Austrália mostraram queda superior a 74% nos valores observados e 72,8% em quantidade. Como ponto positivo, observa-se que novos países tornaram-se importadores do açaí paraense no ano de 2009, como Espanha, Israel, Angola, Porto Rico e Turquia, que, no entanto, são ainda mercados muito incipientes.


**1.1.2. Locais de Produção do açaí:**

O açaizeiro também se constitui na principal fonte de matéria-prima para a agroindústria de palmito no Brasil. Sua maior concentração ocorre em solos de várzeas e igapós do estuário amazônico, com área estimada em 1 milhão de hectares, mas pode ser encontrado como espécie componente do ecossistema de floresta natural ou em forma de maciços conhecidos como açaizais.
 
A produção de açaí extrativo se dá em áreas de ocorrência espontânea da espécie, ou melhor, do gênero Euterpe, em solos úmidos ou às margens de rios e lagos dos estados do Acre, Amapá, Amazonas, Pará, Roraima, Rondônia e Maranhão, na Amazônia Brasileira. No entanto, é na região do estuário do Rio Amazonas, abrangida pelos estados do Amapá e Pará, que se encontram as maiores e mais densas populações naturais dessa palmeira. Dessa forma, essas maiores concentrações ocorrem em solos de várzeas, compondo ecossistemas de floresta natural ou em forma de maciços de açaizais.

Inicialmente, a exploração do açaí era exclusivamente extrativa, mas, desde a década de 1990, em razão do crescimento da valorização comercial, começaram a ser implementadas ações de manejo de açaizais nativos e também de cultivos, em várzea e terra firme, com os cultivos podendo ocorrer em sistema solteiro ou consorciado.

O açaí cultivado está se expandindo, principalmente, em áreas de terra firme de vários estados da Amazônia e no sul da Bahia, onde as condições climáticas são mais favoráveis, com predominância dessa expansão no Estado do Pará.


**1.1.3. Mercado Nacional:**

O açaí é um produto que, tradicionalmente, faz parte da dieta alimentar das pessoas que vivem na Amazônia. Até a década de 1990, o açaí tinha uma participação bastante expressiva na alimentação da população que detinha um baixo poder aquisitivo. O preço acessível e o conhecimento de suas propriedades nutritivas estimulavam o consumo interno.
 
Contudo, no início dos anos 1990, o consumo de açaí começou a apresentar uma expansão bastante rápida, passando também a fazer parte da alimentação das classes de maior renda da região Amazônica. Concomitantemente a esse processo, passou-se a observar um crescimento na demanda nacional (com destaque para São Paulo, Rio de Janeiro e estados da região Nordeste do Brasil) e internacional (Estados Unidos e União Europeia) pela polpa de açaí congelada.

Outro elemento que influenciou o aumento do consumo de açaí na Amazônia foi o processo acelerado de urbanização, pois as pessoas que vinham do interior para morar nas cidades continuaram a manter o hábito de tomar açaí regularmente.

O perfil do consumidor domiciliar de açaí na região metropolitana de Belém prefere o vinho ou suco (74,6%). Já em outros estados brasileiros, o açaí é preferencialmente consumido junto com outros alimentos, como granola, guaraná e frutas. Para o mercado internacional, existem variações de polpa congelada, como no caso das polpas de açaí com xarope de guaraná e outras frutas, que são acrescidas ao produto pelas indústrias de beneficiamento de açaí ainda durante o processamento, de acordo com as especificações dos compradores internacionais. Vale ressaltar que o consumidor das regiões tradicionais, especialmente dos estados do Pará, Amapá e Maranhão, praticamente não aceitam a polpa congelada, por questão de tradição, exigindo o produto processado no mesmo dia do consumo.


**1.1.4. Políticas e legislação:**

Com relação à saúde pública, em agosto de 2007, o açaí apresentou queda nos preços de 33,7%, atribuída pelo Dieese/PA à redução no consumo do fruto em decorrência de quatro mortes ocorridas em 2006 e quatro em 2007, ocasionadas pelo mal-de-chagas, registradas na Região Metropolitana de Belém e no interior do Estado do Pará. Em outubro de 2007, os estabelecimentos comerciais assumiram compromisso com o Ministério Público do Estado (MPE), por meio do Termo de Ajustamento de Conduta (TAC), de se adequar às normas de higiene previstas pela Lei 8.918/94, que dispõe sobre o padrão de produção de bebidas derivadas de frutos, visando evitar o mal-de-chagas, a salmonela, os coliformes fecais, além de outras infecções.

Ainda em relação à legislação, destacando-se o que se refere ao processamento de açaí, foi definido, pelo MAPA, o Regulamento Técnico para a Fixação dos Padrões de Identidade e Qualidade para a Polpa de Açaí (BRASIL, 2000). Este regulamento visa “estabelecer os padrões de identidade e qualidade mínimos que deverão obedecer a polpa de açaí e o açaí destinado para outros fins”. Com a finalidade de aprimorar as ações de controle sanitário na esfera de alimentos, foi instituída em 29 de julho de 2005 a Resolução de Diretoria Colegiada (RDC) nº. 218, que dispõe sobre o Regulamento Técnico de Procedimentos Higiênico-Sanitários para Manipulação de Alimentos e Bebidas Preparados com Vegetais. Essa legislação visa também evitar a ocorrência de surto de Doença de Chagas Aguda, entre outras doenças transmitidas por alimentos. O Regulamento abrange os serviços de alimentação (lanchonetes, quiosques, barracas, ambulantes e similares) que executam as seguintes atividades: preparo, acondicionamento, armazenamento, transporte, distribuição e comercialização de alimentos e bebidas preparados com vegetais, definindo ações relacionadas à aquisição, recebimento e armazenamento das matérias-primas; ingredientes, embalagens e insumos; regras em relação aos manipuladores de alimentos e preparo e exposição à venda de alimentos e bebidas, o que inclui o açaí.

No Estado do Pará, foi criado o Programa Estadual da Qualidade do Açaí, que tem a participação de instituições como Sespa, Sebrae-Pará, Senai, Anvisa, Embrapa, Emater, Instituto Evandro Chagas, entre outras. No Programa, está em curso a capacitação de batedores de açaí em boas práticas alimentares, de acordo com as normas do Programa Alimento Seguro (PAS), já tendo sido obtidos avanços significativos, de acordo com seus objetivos.


**1.1.5. As exportações de frutas, polpas e sucos no Estado do Pará:**

O crescimento do valor das exportações de frutas, polpas e sucos de frutas do Estado do Pará foi de US$ 33,94 milhões em 2005, com aumento de 45,73% em relação a 2004. Saltou de 5.418 toneladas exportadas em 2004 para 11.350 toneladas em 2009, passou de US$ 6,42 milhões para US$ 27,97 milhões. Em 2009, a exportação da castanha foi responsável por US$ 7,18 milhões, enquanto o cacau gerou receita de US$ 726,6 mil, que, somada com as exportações de frutas, obtêm-se o valor de US$ 35,16 milhões. No Estado do Amapá, o arranjo produtivo local do açaí teve um movimento de R$ 177 milhões, representando o terceiro maior volume do valor recebido das exportações em 2009, correspondendo a 5% do total das divisas.


**1.2. Características da espécie e relações com o meio ambiente:**


**1.2.1. Biologia Reprodutiva:**

O açaizeiro inicia a fase reprodutiva por volta de 4 a 5 anos após a germinação, com a emissão de eventos de floração e frutificação registrados o ano todo. O pico de florescimento ocorre de janeiro a maio e o de frutificação, de agosto a dezembro, mas pode variar com o local e o ecotipo. Não apresenta dormência de sementes, sendo considerada uma planta heliófila, com idade de reprodução entre 5 e 10 anos e tempo de vida útil entre 10 e 25 anos.


**1.2.2. Relações com o Clima:**

O açaizeiro ocorre naturalmente na região do estuário amazônico em áreas alagadas (várzea e igapó), mas se adapta bem às condições de terra firme com boa distribuição pluviométrica. É típico de clima tropical chuvoso, sendo amplamente adaptado à região Amazônica, ocorrendo em todos os tipos climáticos segundo a classificação de Köppen: Afi, Ami e Awi. Mas, independentemente do ambiente, a luz é um fator limitante para o bom desenvolvimento da planta. Possui características das espécies arbóreas do grupo ecológico secundárias: não apresenta dormência de sementes, a regeneração é por banco de plântulas e tolera o sombreamento somente no estágio juvenil. A abertura dos estômatos depende mais da radiação solar que do déficit de pressão de vapor.

Em áreas próximas a Belém, PA, onde a temperatura média anual atinge 25,9 ºC, a precipitação alcança 2.761 mm/ano, a evapotranspiração é de 1.455 mm, a umidade relativa do ar de 86% e a insolação é de 2.389 horas anuais, características do clima tipo Afi, a espécie apresenta excelente desenvolvimento, com as populações espontâneas densas e a produtividade de frutos alta. Já em Santarém, PA, onde a temperatura média anual é de 26 ºC, a precipitação atinge 2.096 mm, a evapotranspiração é de 1.558 mm, a umidade relativa do ar é de 84% e a insolação é de 2.091 horas/ano, as populações também são densas e apresentam bom desenvolvimento, mas a produtividade de frutos é menor.

O açaí pode ser cultivado em algumas áreas do litoral paulista, onde a temperatura média anual é de 21 ºC, sendo provavelmente próxima do limite mínimo de exigência térmica para a espécie. Mas não se adapta a áreas mais altas desta região, sujeitas a ventos frios durante o inverno.


**1.2.3. Relações com o Solo:**

Ocorre naturalmente tanto nos solos eutróficos (solos  ricos em nutrientes,  em composição química)  como nos distróficos (solos pobres em nutrientes, em composição química) , sendo predominante em Gleissolos de várzeas do estuário. Esses solos são ácidos, argilo-siltosos e com boa fertilidade natural, em decorrência da deposição de sedimentos trazidos pelas marés. É espécie dominante nas florestas de várzeas que apresentam caráter oligárquico, determinado pelo regime de inundações, pois um número reduzido de espécies arbóreas dispõe de mecanismos adaptativos para sobreviverem em solos com baixo oxigênio. No caso do açaizeiro, esses mecanismos estão representados por adaptações morfológicas e anatômicas, como raízes que emergem do estipe acima da superfície do solo, presença de lenticelas e de aerênquimas nas raízes.

Tem bom desenvolvimento em áreas de terra firme, especialmente em Latossolos amarelo textura média a pesada. Mas prefere ambientes de várzea e igapós, geralmente em solos hidromórficos tipo Gley pouco úmico, por possuir alto teor de matéria orgânica.


**1.2.4. Características Botânicas do Açaí:**


**1.2.4.1. Frutos:**

Cada fruto é uma drupa globosa. Contém mesocarpo fino, de 1 mm a 2 mm de espessura, de coloração variável e parte comestível (epicarpo e mesocarpo), representando 7 % a 25 % do fruto, com média de 26,54 %, sendo o epicarpo indistinto. Porém, há variações acentuadas, principalmente, em função da planta matriz. A maior parte do fruto é composta pelo endocarpo esférico e fibroso na parte externa e na parte interna, contém uma semente com eixo embrionário diminuto e tecido de reserva formado por sílica e rico em lipídios.


**1.2.4.2. Sementes:**

A semente possui um envoltório fibroso, endocarpo duro e embrião diminuto, com endosperma abundante e ruminado, de comportamento recalcitrante. No entanto, podem ser encontrados frutos com mais de um embrião. 
                                                        
A principal característica do açaizeiro é que, na planta jovem oriunda do plantio de uma muda e, consequentemente, da semeadura de uma semente, ocorre a emissão de perfilhos na base do estipe principal, formando um conjunto denominado touceira.  


**2. Produção:**

Neste item, são abordados aspectos relacionados ao cultivo do açaizeiro para a produção de frutos em terra firme, em tópicos como propagação, plantio, tratos culturais, doenças e insetos-praga, colheita, custos e rentabilidade.

**2.1 Coeficientes técnicos, custos e rentabilidade:**

Encontram-se os coeficientes técnicos para a implantação e manutenção de 1 ha de açaizeiro, até o quinto ano de plantio, em terra firme, no espaçamento de 5m x 5m. Como se pode observar, nos três primeiros anos do plantio, não há receitas, apenas custos, uma vez que a produção de frutos inicia-se a partir do terceiro ano. No quarto ano, há a produção de 72 rasas que, vendidas ao preço médio de R$ 25,00, darão uma receita de R$ 1.800,00. Porém, sem benefício líquido. A partir do quinto ano de plantio, é previsto um benefício líquido de R$ 264,00 e com o ponto de equilíbrio acontecendo a partir do sexto ano.


**2.2 Escolha e preparo de área para plantio:**

O cultivo do açaizeiro deve ser indicado em áreas já exploradas com plantios sucessivos de espécies de ciclo curto e/ou médio, submetidas à mecanização, tratos culturais frequentes e fertilização química e orgânica, com cobertura vegetal de pastagem. A maioria é formada por área degradada, como também por capoeira fina (macega) com dificuldades de regeneração natural. Alternativamente, pode-se implantar também em áreas com vegetação secundária de pequeno porte. Áreas com vegetação primária devem ser evitadas, em consequência dos danos ambientais e do maior custo com o preparo, que depende da derrubada da vegetação.

O preparo de área deve consistir, basicamente, na roçagem da vegetação, piqueteamento, aplicação de herbicida ou capina manual na área ao redor do piquete, abertura de covas e plantio. No Estado do Pará, é comum a implantação do açaizeiro em cultivos decadentes de pimenta-do-reino, maracujazeiro, mamoeiro, abacateiro, entre outras fruteiras. Nesses casos, o preparo da área consiste na roçagem das linhas e abertura das covas onde serão plantados os açaizeiros, com posterior remoção dos tutores e das plantas.

O açaizeiro pode ser plantado solteiro, consorciado ou associado a outras culturas, tais como culturas alimentares, semiperenes e perenes, em espaçamentos indicados para cada condição. A melhor opção é o plantio consorciado para garantir diversificação de renda ao produtor, especialmente colocando nas entrelinhas do plantio do açaizeiro culturas alimentares (milho e feijão), as quais dão um retorno mais rápido ao produtor.


**2.3. Custo do sistema de irrigação por aspersão:**

A produtividade média do sistema irrigado é de 120 latas/ha no quinto ano, quando se inicia a irrigação, esperando atingir 4,5 t/ha (321 latas) na estabilização. Em virtude de problemas climáticos, a safra de 2005 foi considerada 20% inferior à de 2004, e esperava-se em 2006 atingir a média de 180 latas/ha. O procedimento adotado é que os açaizeiros aos 5 anos, quando se inicia a irrigação por aspersão, tenham três estipes formados e três estipes pequenos. Com o manejo, espera-se que, aos 10 anos, tenham três estipes adultos e três com 5 anos, todos produzindo.

Em 2006, o custo de uma lata de fruto de açaí irrigado era de R$ 13,78, considerando uma produtividade de 120 latas/ha. Com a estabilização da produção, em 180 latas/ha, este custo decrescia para R$ 10,57/lata, permitindo dobrar a receita líquida.



**2.4. Métodos de propagação:**

O açaizeiro pode ser propagado por via sexuada e assexuada. A propagação por sementes é o método mais comum, especialmente para a produção de grande quantidade de mudas, pois uma planta pode produzir mais de 6.000 sementes por ano. A propagação assexuada pode ser obtida pela retirada de perfilhos ou brotações que surgem de forma espontânea na região logo abaixo do emaranhado de raízes.


**2.4.1. Propagação assexuada:**

Em virtude da variabilidade genética existente nas populações naturais de açaizeiro, altos ganhos genéticos para produtividade poderão ser aferidos por meio de técnicas de melhoramento genético. Para tanto, a propagação vegetativa torna-se uma ferramenta valiosa ao visar à obtenção futura de plantios mais uniformes e de alta produtividade, além da produção de sementes melhoradas em pomares de sementes clonais. Graças à capacidade de perfilhamento da espécie, o método de propagação assexuada que oferece resultados mais promissores é o de propagação por meio de perfilhos. Entretanto, esse método demanda mão de obra e é bastante demorado. Em virtude dos baixos índices de sobrevivência dos perfilhos em campo, até o momento, essa técnica não é indicada para produção de mudas em escala comercial. A quantidade dessas brotações depende do genótipo e do ambiente. Elas surgem, inicialmente, na base do estipe principal e, posteriormente, na dos estipes secundários. Contudo, algumas plantas, independentemente do ambiente, não exibem a capacidade de emitir brotações e apresentam estipe solitário.

Informações técnicas sobre o manejo e preparo de perfilhos para enraizamento de açaizeiro ainda são escassas. Em trabalhos com esta espécie, os relatos de preparo e manejo de perfilhos não são bem detalhados. Sabe-se que, desde o momento da extração, condução de perfilhos em ambiente de enraizamento até o plantio, existem fatores intrínsecos e extrínsecos que influenciam o enraizamento e a sobrevivência da planta. Dificuldades são encontradas na escolha de material vegetativo, haja vista a inexistência de um padrão de altura e diâmetro. Além disso, fatores como genótipo, ambiente, idade e fertilidade do solo influenciam no número de emissões de perfilhos. Experimentos com enraizamento de perfilhos de açaizeiro, utilizando diferentes matrizes e dois diâmetros do coleto, identificaram porcentagem de enraizamento variando de 30% a 60% para perfilhos com diâmetro do coleto maior que 2 cm

Outra forma de propagação assexuada que vem sendo investigada envolve o processo in vitro, apresentando algum sucesso com a utilização de embriões zigóticos. Porém, ainda não se dispõe de protocolos que possibilitem a obtenção de plântulas por meio da cultura de tecidos somáticos.


**2.4.2. Propagação sexual (sementes):**

A estrutura usada como semente corresponde ao endocarpo, que contém em seu interior uma semente, com eixo embrionário diminuto e abundante endosperma. O endocarpo é, aproximadamente, esférico, com comprimento e diâmetro médio de 1,23 cm e 1,45 cm, respectivamente, e representa 73,46% do peso do fruto.

Em decorrência da grande variação para peso do fruto (0,8 g a 2,3 g), o número de sementes contidas em um quilograma também é bastante variável (1.250 sementes a 435 sementes), mas, em média, encontram-se 667 sementes/kg. Vale ressaltar que sementes oriundas de frutos recém-colhidos e imediatamente processados apresentam alta porcentagem de germinação (acima de 90%).


**2.4.3. Semeadura e formação de mudas:**

As sementes podem ser semeadas em sementeiras ou diretamente em sacos de polietileno preto para produção de mudas. A escolha do local de semeadura vai depender da quantidade de mudas a serem produzidas. Independentemente do processo, as sementes devem ser obtidas de frutos recém-colhidos, imediatamente despolpados, retirando-se os resíduos da polpa pela lavagem das sementes, sendo, em seguida, semeadas 


**2.4.3.1. Formação das mudas:**

Após a repicagem para os recipientes, as mudas devem ser mantidas em viveiros. O período compreendido da repicagem até a muda no ponto de plantio decorre de 6 a 8 meses, mas depende dos tratos culturais realizados na fase de viveiro (adubação, irrigação, monda, controle de insetos e doenças). Caso as mudas sejam mantidas por um período superior a 8 meses, deve-se realizar a repicagem para sacos maiores (17 cm x 27 cm x 0,10 cm).

As mudas podem ser mantidas em viveiros rústicos cobertos com folhas de palmeiras ou em telado sombrite com 50% de sombra e ter altura mínima de 2 m. Dentro do viveiro, os canteiros devem ter 1,5 m de largura e 20 m de comprimento, mantendo distância de 50 cm entre si, de modo a facilitar a movimentação de pessoas.

A Comissão Estadual de Sementes e Mudas do Pará estabeleceu normas e padrões para mudas fiscalizadas de açaizeiro, as quais devem apresentar as seguintes características:
-Ter altura uniforme, aspecto vigoroso, cor e folhagem harmônicas.
-Possuir, no mínimo, cinco folhas fisiologicamente ativas (maduras), pecíolos longos e as folhas mais velhas com folíolos separados. O coleto deve apresentar a espessura da base maior que a da extremidade das mudas.
-Conter de 4 a 8 meses de idade, a partir da emergência das plântulas.
-Apresentar altura de 40 cm a 60 cm, medidos a partir do colo da planta.
-Apresentar sistema radicular bem desenvolvido e ter suas extremidades aparadas quando ultrapassar o torrão.
-Isentas de pragas e moléstias (Regulamento da Defesa Sanitária Vegetal).
-A comercialização das mudas somente será permitida em torrões, acondicionadas em sacos de plástico sanfonados e perfurados ou equivalentes, com, no mínimo, 15 cm de largura e 25 cm de altura.
-Não apresentar raízes expostas acima do coleto.
-Na fase final do viveiro, que corresponde a cerca de 2 meses antes do plantio, o sombreamento deve ser reduzido deixando as mudas submetidas à condição de 70% a 80% de luminosidade para evitar queima das folhas quando forem levadas ao campo 


**2.4.3.2. Semeadura:**

A semeadura direta em sacos para produção de mudas é recomendada quando a quantidade de mudas for pequena (500 a 1.000). Os sacos de polietileno preto devem ter dimensão de 15 cm x 25 cm x 0,10 cm, contendo como substrato terriço (60%), serragem (20%) e esterco curtido (20%), o que equivale à proporção volumétrica de 3:1:1.

A semeadura em sementeira deve ser recomendada quando a quantidade de mudas for grande (acima de 5.000), pois permitirá economia de mão de obra, além de seleção criteriosa de plântulas na ocasião da repicagem. O substrato da sementeira deve ser constituído pela mistura de areia lavada e serragem curtida, na proporção volumétrica de 1:1. As sementes devem ser semeadas em sulcos de 4 cm de distância, com 2 cm de afastamento entre sementes e a uma profundidade de 1 cm. As plântulas, ao atingirem o estádio de “palito” acima de 2 cm de altura, devem ser repicadas para os sacos de mudas contendo o mesmo substrato descrito anteriormente.


**2.5. Plantio:**

O plantio do açaizeiro em terra firme deve ser efetuado no início do período chuvoso, em covas com dimensões de 40 cm x 40 cm x 40 cm, previamente adubadas (pelo menos 30 dias antes do plantio) com duas pás de esterco curtido, o que equivale a aproximadamente 10 kg, ou com uma pá de cama de galinha e 200 g de superfosfato triplo (SFT), cobrindo-as, em seguida, até o momento do plantio.

Na ocasião do plantio, devem-se distribuir as mudas em local próximo às covas, reabrir as mesmas e misturar a porção da terra retirada com os 200 g de STF e o adubo orgânico. Deve-se retirar as mudas dos sacos de plástico por meio de um corte nos mesmos e plantá-las no centro das covas, cobrindo o torrão da muda com a mistura da terra até a região do coleto, e fazer uma pressão neste local para evitar a formação de bolhas de ar e apodrecimento de raízes. Mudas mal plantadas (com o coleto exposto) trarão problemas mais tarde ao produtor, como: tombamento com facilidade, ponto de penetração de insetos e microrganismos, etc.

Recomenda-se, após o plantio, o uso de cobertura morta em volta da muda, principalmente em plantios fora de época. Esse procedimento visa minimizar os efeitos de possíveis veranicos que possam ocasionar uma  escassez de água acentuada e levar à morte das mudas recém-plantadas. Além disso, a cobertura morta serve também para controle parcial do mato (plantas daninhas) em volta da muda.O sombreamento nos primeiros meses das palmeiras é fundamental para a sobrevivência, pois funciona como redutor do metabolismo vegetal, podendo ajustá-lo às condições insatisfatórias, como a escassez de água no solo e a alta luminosidade.

Se for utilizada irrigação, o plantio pode ser efetuado em qualquer época do ano, adotando-se os mesmos procedimentos indicados para o plantio em terra firme. No caso de plantio em área de várzea, o mesmo deve ser realizado no final do período chuvoso.


**2.6. Colheita**
A colheita de cachos é efetuada, aproximadamente, 5 a 6 meses ou, aproximadamente, 180 dias após a fecundação das flores, ocasião em que os frutos apresentam coloração roxo-escura ou verde-escura, dependendo do tipo, sendo recobertos por uma camada esbranquiçada.

A colheita é uma operação onerosa e difícil e deve ser feita sempre no início da manhã, com o auxílio de facas bem afiadas para a realização de cortes no cacho próximos à inserção do estipe. Em plantas altas e com estipes finos, a colheita constitui-se uma operação onerosa e difícil de ser realizada. Durante a colheita, cuidados especiais são necessários para que não haja desprendimento de quantidade elevada de frutos das ráquilas. Em plantas no início da produção, a colheita é mais facilitada.
A preferência da colheita pela manhã visa evitar que os cachos sejam desbolados nos horários mais quentes e chuvosos do dia, que dificultam também a escalada nas palmeiras, pois os estipes ficam quentes e escorregadios. Da mesma forma, um bom horário é logo após o raiar do dia, quando os ventos são brandos. Outro fator determinante para a colheita no início da manhã está relacionado ao tempo gasto com a embalagem dos frutos e transporte, uma vez que os frutos colhidos devem chegar aos grandes centros consumidores, principalmente em Belém, PA, ainda nas primeiras horas do dia seguinte ao da colheita.

Durante a colheita, devem ser estabelecidos padrões de higiene, de modo a garantir a qualidade do produto a ser obtido. Após a colheita, o cacho deve ser depositado em lonas plásticas limpas e não ao solo, para se evitar a contaminação dos frutos. Em seguida, deve-se realizar a remoção de sujeiras (restos florais, de ráquilas, etc.), de frutos verdes atacados por insetos, doenças e animais e de produtos indesejáveis à comercialização e ao processamento. Após a retirada dos frutos, os cachos secos devem ser mantidos na área, pois servem de adubo orgânico.  

Escaladores habilidosos são capazes de passar de um estipe para outro de uma mesma touceira, sem descer ao solo, colhendo de três a cinco cachos em uma única escalada, desde que o peso total não ultrapasse 15 kg. Normalmente, um escalador experiente é capaz de colher cerca de 150 kg a 200 kg de frutos, o que corresponde a, aproximadamente, 50 a 60 cachos em uma jornada de 6 horas de trabalho.

Com a intensificação e racionalização do cultivo do açaizeiro, a operacionalização da colheita precisa ser substancialmente melhorada, tendo em vista que, em muitas áreas onde a cultura está sendo implantada, há carência de pessoal habilitado em escalar palmeiras, além de o sistema tradicional ser bastante oneroso e com baixo rendimento de mão-de-obra. Um equipamento que vem sendo testado, com relativo sucesso, na Embrapa Amazônia Oriental, para a colheita de cachos de pupunheira (Bactris gasipaes), pode ser utilizado também na colheita do açaizeiro. Esse equipamento consiste de uma vara de alumínio, com 6 m de comprimento, que contém uma lâmina para o corte, um recipiente para a recepção do cacho e uma roldana que permite a descida e a subida do recipiente, em uma das extremidades.

Os frutos devem ser acondicionados, preferencialmente, em caixas de plástico, pela melhor conservação que estas proporcionam. Cestos confeccionados com fibras vegetais (paneiros) também podem ser utilizados. Os cestos oferecem boa ventilação, o que favorece a conservação dos frutos com capacidade variável, comportando, normalmente, de 14 kg ou 28 kg de frutos. Já as caixas evitam o contato direto dos frutos com o solo ou com qualquer agente contaminante, como combustível e produtos químicos.


**2.7. Tratos Culturais:**

Neste item, são abordados aspectos relacionados à nutrição e adubação, manejo de perfilhos, limpeza de touceiras, controle do mato, irrigação e manejo de inflorescências.


**2.7.1. Nutrição e Adubação**

O crescimento adequado das plantas é alcançado quando são proporcionadas as mesmas condições para a absorção, distribuição e proporcionalidade entre os nutrientes. Quantidades excessivas podem causar antagonismo entre eles, ocasionando perdas consideráveis na produção das culturas, assim como a redução dos nutrientes. Portanto, a análise do solo é uma prática indispensável para o sucesso do crescimento e a adaptação das plantas de açaizeiro.

Os estudos sobre nutrição e adubação do açaizeiro são ainda incipientes, não dispondo de informações que permitam avaliar o estado nutricional das plantas com precisão e estabelecer recomendações para adubação de manutenção. Resultados obtidos em experimentos sobre nutrição evidenciam que os macronutrientes interferem na produção de matéria seca em plantas jovens de açaizeiro, na seguinte ordem: K > Mg > P > N > Ca > S. Em decorrência, a determinação dos teores desses nutrientes nas folhas e raízes de plantas com e sem sintomas de deficiência fornecem indicação preliminar para avaliação do estado nutricional do açaizeiro.Com relação à adubação de manutenção, alguns procedimentos têm sido indicados para solos de terra firme (baixa fertilidade natural), seja para plantio solteiro ou consorciado.

**2.7.1.1. Adubação em cultivo solteiro e consorciado**


**2.7.1.1.1. Em consórcio com maracujazeiro, bananeira ou mandioca**

Para o açaizeiro, no primeiro ano do plantio, além da adubação na cova, devem ser aplicados a cada dois meses 50 g da mistura composta de cinco partes da formulação 10.28.20 mais duas partes de cloreto de potássio; nos anos seguintes, aplicar a cada 2 meses 100 g (no segundo ano), 150 g (no terceiro ano), 200g (no quarto ano) e 250 g a 300 g (a partir do quarto ano do plantio) da mesma mistura, nas distâncias já mencionadas anteriormente. Como também deve ser efetuada a adubação orgânica de 10 L a 20 L de esterco curtido, no início do período chuvoso, quando se inicia a fase reprodutiva, a adubação potássica deve ser aumentada, aplicando três vezes (início, meio e final do período chuvoso) uma mistura composta de 290 g de N.P.K (10.28.20) e 110 g de cloreto de potássio por aplicação, a uma distância de 150 cm da touceira. Na última aplicação, recomenda-se aplicar 10 g a 20 g de bórax por touceira na coroa foliar.   
                                                 
Para o maracujazeiro, usar na cova 10 L de esterco mais 200 g de superfosfato triplo; do segundo ano do plantio em diante, deve-se aplicar 10 L a 20 L de esterco curtido a cada 6 meses. Para a bananeira, usar na cova 10 L de esterco mais 200 g de superfosfato triplo; no segundo ano do plantio, aplicar, a cada 2 meses, 200 g da mistura formada por cinco partes da formulação (10.28.20) e duas partes de cloreto de potássio. A partir do terceiro ano do plantio, aplicar 10 L a 20 L de esterco curtido a cada 6 meses. Para a mandioca, colocar na cova 1 L de esterco curtido mais 25 g da formulação 10.28.20.


**2.7.1.1.2. Em cultivo consorciado com cupuaçuzeiro**

Para o açaizeiro, no primeiro ano do plantio, além da adubação na cova, devem ser aplicados a cada dois meses 50 g da mistura composta de cinco partes da formulação 10.28.20 mais duas partes de cloreto de potássio; nos anos seguintes, aplicar a cada 2 meses 100 g (no segundo ano), 150 g (no terceiro ano), 200g (no quarto ano) e 250 g a 300 g (a partir do quarto ano do plantio) da mesma mistura, nas distâncias já mencionadas anteriormente. Como também deve ser efetuada a adubação orgânica de 10 L a 20 L de esterco curtido, no início do período chuvoso, quando se inicia a fase reprodutiva, a adubação potássica deve ser aumentada, aplicando três vezes (início, meio e final do período chuvoso) uma mistura composta de 290 g de N.P.K (10.28.20) e 110 g de cloreto de potássio por aplicação, a uma distância de 150 cm da touceira. Na última aplicação, recomenda-se aplicar 10 g a 20 g de bórax por touceira na coroa foliar. Para o cupuaçuzeiro, colocar na cova do plantio 10 L a 20 L de cama de aviário, acrescido de 100 g de FTE (Fritted Trace Elements) Br 13. Ainda no primeiro ano, devem ser realizadas seis aplicações, espaçadas a cada 2 meses, de 100 g da formulação 10.28.20. No segundo ano do plantio, deve-se aplicar no início das chuvas 10 L a 20 L de cama de aviário e 100 g de FTE Br 13 mais 900 g a 1.200 g de 10.28.20, dividido em três parcelas iguais, no início, meio e final das chuvas, além de 30 g de bórax. A partir do terceiro ano, deve-se aplicar 10 L a 20 L de cama de aviário e 100 g de FTE Br 13, mais 1.500 g de 10.28.20, dividido em três parcelas iguais, no início, meio e final das chuvas, além de 30 g de bórax.


**2.7.1.1.3. Em cultivo solteiro**

No primeiro ano do plantio, além da adubação na cova, devem ser efetuadas três aplicações de adubo químico (N.P.K, nitrogênio, fósforo e potássio + micronutrientes), na formulação de 10.28.20 ou em outra proporção, conforme a análise do solo, na dosagem de 100 g por aplicação e distribuída em torno da planta, num raio de 30 cm de distância. No segundo ano, devem ser realizadas três aplicações do mesmo adubo químico (início, meio e final do período chuvoso), na dosagem de 150 g por aplicação a uma distância de 50 cm da planta, além de 10 L de esterco curtido aplicado no início das chuvas. No terceiro ano, deve-se efetuar três aplicações da mesma formulação, na dosagem de 200 g, distanciando 100 cm da touceira e mais 20 L de esterco curtido. A partir do quarto ano do plantio, quando se inicia a fase reprodutiva, a adubação potássica deve ser aumentada, aplicando três vezes (início, meio e final do período chuvoso) uma mistura composta de 290 g de N.P.K (10.28.20) e 110 g de cloreto de potássio por aplicação, a uma distância de 150 cm da touceira. Na última aplicação, recomenda-se aplicar 10 g a 20 g de bórax por touceira na coroa foliar.


**2.7.2. Necessidades de irrigação:**

A disponibilidade de água no solo é o fator primordial no crescimento do açaizeiro. Há relatos de que o deficit hídrico provoca a diminuição nas atividades fisiológicas do açaizeiro (fotossíntese, condutância estomática e transpiração).                                                                                                                                                               
Na Amazônia, o cultivo do açaizeiro em terra firme deve ser realizado em áreas de tipo climático Afi. Porém, ele pode ser cultivado nos demais tipos climáticos, desde que haja a suplementação de água por meio de irrigação, no período de menor precipitação pluviométrica.
 
Em cultivos de açaizeiro, na Amazônia, a irrigação vem sendo realizada de forma empírica, pois não existem estudos específicos sobre sua necessidade hídrica. Nessa região, a irrigação é empregada durante o período de estiagem, na forma de irrigação suplementar, em cultivos estabelecidos em solos de terra firme e submetidos aos tipos climáticos Ami e Awi, que apresentam períodos de estiagem de 3 a 5 meses.
 
Nos primeiros anos de implantação da cultura, a irrigação deve ser feita por microaspersão ou por gotejamento, quando necessitam de pouca água. Ao iniciar a fase produtiva (floração e frutificação), aconselha-se a irrigação por aspersão, que possibilita maior disponibilidade de água. Como exemplo sobre a necessidade de irrigação, pode-se mencionar o experimento instalado no final do período chuvoso (maio), no município de Castanhal. Neste local, foi registrada a perda de 95% das mudas, após 6 meses de plantio, mostrando a necessidade de irrigação e de se realizar o plantio no início das chuvas. Em algumas situações, como nos anos de ocorrência do fenômeno “El niño”, a irrigação é também necessária, mesmo em locais com tipo climático Afi, particularmente se o pomar estiver instalado em solos com teor de argila inferior a 30%.
 
Como na maioria das palmeiras, o primeiro sintoma visível do deficit de água na planta manifesta-se pela não abertura completa dos folíolos e, depois, pelo retardamento no ritmo de abertura das folhas. Assim, em plantas com estresse por falta de água, é comum encontrar no ápice duas ou mais folhas não completamente abertas e em forma de flecha. Esse fenômeno, em muitos casos, também está associado à deficiência de boro, pois a absorção desse nutriente fica limitada pela deficiência de água no solo.
 
A falta de água ocasiona perda de folhas em decorrência do fechamento dos estômatos, menor transpiração e consumo de CO2 (Fotossíntese). Em consequência disso, há a aceleração do envelhecimento, da queda de folhas e, finalmente, a morte da planta. No solo, a desidratação do tecido vegetal é decorrente da perda da turgescência celular (relativo a capacidade de absorção de água em tecidos vegetais, como  as folhas) , o que afeta os processos de divisão, expansão celular, fotossíntese, produção e translocação de assimilados, podendo levar à morte, dependendo da intensidade e duração do deficit.
A utilização de um sistema de irrigação no cultivo de açaizeiro tem como principal vantagem a produção contínua de frutos, especialmente na entressafra, época em que o preço alcança o triplo da safra, garantindo, assim, maior lucro ao produtor.


**2.7.3. Manejo de inflorescências:**

No Estado do Pará, apesar de o açaizeiro produzir o ano todo, o maior volume de comercialização de frutos ocorre no segundo semestre do ano, coincidindo com o período menos chuvoso, ocasião em que o preço dos frutos alcança menor valor. Então, a produção de frutos fora de safra (no primeiro semestre) garante ao produtor um melhor preço.

A principal forma de produzir frutos o ano todo é manter as plantas bem irrigadas em todos os meses. Há indícios de a produção na entressafra estar relacionada com o local de origem dos frutos, pois alguns municípios do Pará, como Gurupá e, principalmente, dos estados do Amapá e do Maranhão, a maior produção ocorre no período mais chuvoso e abastece o mercado na entressafra.

Para açaizeiros que produzem frutos na safra, pode-se direcionar sua produção para a entressafra por meio do manejo de inflorescências, ou seja, eliminando todas as inflorescências existentes nos estipe que forem emitidas entre os meses de março a junho e mantendo uma boa irrigação e adubação.


**2.7.4. Manejo de perfilhos, limpeza das touceiras e controle do mato:**


**2.7.4.1. Controle do mato:**

Há vários métodos de controle de plantas invasoras: o preventivo, o manual, o mecânico, o físico, o químico e o integrado (associação de dois ou mais métodos). No preventivo, devem-se realizar práticas para evitar o espalhamento de sementes das plantas invasoras (limpeza de tratores,  máquinas e demais implementos agrícolas; usar esterco ou matéria orgânica curtidos; usar mudas isentas de plantas invasoras; eliminar as plantas invasoras indesejáveis). No método manual, são realizadas capinas, roçagens, coroamento e arranquios nas áreas onde ocorrem as invasoras. No mecânico, usa-se roçadeira rotativa ou grade acoplada ao trator, ou roçadeira costal motorizada. Esse método é indicado no controle das invasoras de reprodução sexuada, sempre no início da produção de sementes. No método físico, realiza-se a cobertura do solo por meio de cobertura morta (serragem, casca de arroz ou outros materiais orgânicos curtidos colocados ao redor da touceira, ocupando a área de projeção da copa da planta, mas deve-se evitar capim seco) ou viva (plantando leguminosas nas entrelinhas). No método químico, utilizam-se herbicidas específicos para plantas invasoras de folhas largas e estreitas. Recomenda-se seguir as especificações existentes no rótulo da embalagem, sendo aplicado em dias sem chuva e nos horários mais amenos (início da manhã ou final da tarde). Na aplicação de herbicidas no período chuvoso, deve-se utilizar espalhante adesivo.

No primeiro ano de plantio, o controle do mato deve ser realizado por roçagem mecânica com trator, nas entrelinhas, e manual, com enxadas, dentro das linhas. A partir do segundo ano, o controle do mato dentro das linhas de plantio deve ser efetuado com a aplicação de herbicidas à base de glifosato. Geralmente, essas práticas são feitas no início do período chuvoso para facilitar a aplicação dos adubos. No cultivo solteiro, o espaçamento usado permite que o captel de folhas, a partir do terceiro ano, produza sombreamento no solo reduzindo a agressividade do mato cujo controle, nesse caso, deve ser feito apenas com roçagens anuais. Durante o período seco, é comum o emprego de gradagem nas entrelinhas, como forma de evitar a entrada de fogo.

Na Embrapa Amazônia Oriental, tem-se usado o controle integrado associado ao controle mecânico (capinas ou roçagens e coroamento) x controle químico (herbicidas) x controle cultural (cobertura morta ou viva). Por esse procedimento, nos três primeiros anos após a implantação da cultura do açaizeiro solteiro, são necessárias três a quatro roçagens por ano e a mesma quantidade de coroamento, feitos em volta das touceiras. Essa última operação pode ser efetuada com herbicidas à base de glifosato ou paraquat. O glifosato tem a vantagem de não provocar danos à planta de açaizeiro, nas dosagens indicadas no rótulo do produto para o controle de plantas daninhas. Convém ressaltar, porém, que esses produtos ainda não foram registrados para uso na cultura do açaizeiro.

Recomenda-se colocar, nos coroamentos, cobertura morta (serragem curtida, engaço de dendê, casca de arroz curtida ou outro material disponível na propriedade, com exceção do resto de capim seco oriundo de plantas invasoras, pois ocasionará o aparecimento de novas plantas daninhas e dificultará o controle do mato) ou viva (de preferência leguminosas).


**2.7.4.2. Manejo de perfilhos:**

O número excessivo de perfilhos ou brotações em uma touceira reduz o crescimento da planta-mãe, pois uma parte considerável de fotoassimilados é mobilizada para a formação do sistema radicular dos perfilhos. Assim sendo, faz-se necessário efetuar o desbaste dos mesmos, de tal forma que cada touceira apresente, no máximo, quatro plantas (a mãe e mais três perfilhos em diferentes idades e bem desenvolvidos). Esse desbaste deve ser realizado anualmente, no período chuvoso. Recomenda-se a eliminação das brotações novas, preferencialmente.

Outro aspecto que deve ser considerado no manejo das touceiras está relacionado à altura dos estipes. Quando um estipe atinge altura que dificulte sobremaneira a colheita dos frutos, é conveniente eliminá-lo. Na sequência, recomenda-se a condução do perfilho mais velho da touceira para substituir o que foi derrubado.


**2.7.4.3. Limpeza das touceiras:**

Consiste na retirada das folhas secas que ficam aderidas às plantas pela bainha foliar, mesmo após a sua queda. Essa prática favorece o crescimento do diâmetro dos estipes, diminui a incidência de aranhas caranguejeiras e de outros animais peçonhentos, além de facilitar a colheita dos cachos. Após a retirada das folhas secas, recomenda-se cortá-las e espalhá-las em volta da planta (na parte do coroamento) ou na linha de plantio entre as plantas. Essa prática favorece a manutenção de umidade.


**2.8. Sementes para cultivo:**

O cultivo de açaizeiro para frutos em terra firme pode ser efetuado com o uso de sementes de populações naturais (ecotipos) ou de programas de melhoramento.

Sementes oriundas de populações naturais, ecotipos ou variedades, além de ocorrerem em locais distintos, diferem em alguma característica morfológica, podendo-se mencionar: o açaí branco, o açaí roxo ou comum, o açaí-açu, o açaí-chumbinho, o açaí-espada, o açaí-tinga e o açaí-sangue-de-boi. Esses tipos se diferenciam pela coloração dos frutos quando maduros, número de perfilhos na touceira, tamanho e peso dos cachos e de frutos, ramificação do cacho ou coloração e consistência da bebida, mas necessitam ser caracterizados e avaliados morfológica e agronomicamente. Apesar de abundantes na Amazônia, apresentam ampla variação, o que pode oferecer uma incerteza ao produtor.
 
Sementes de programas de melhoramento são mais escassas, havendo no mercado, oficialmente, somente as da cultivar BRS Pará, lançada em novembro de 2004, caracterizada como uma população melhorada. Desenvolvida pela Embrapa Amazônia Oriental, foi obtida por três ciclos de seleção fenotípica praticados na coleta, na coleção de germoplasma e em um campo isolado. Na coleta, a seleção foi efetuada em matrizes de 16 locais dos Estados do Pará, Amapá e Maranhão, e envolveu milhares de plantas, das quais foram selecionadas 134, por apresentarem características desejáveis para a produção de frutos. Com seus frutos, foi instalada uma Coleção de trabalho em área de terra firme, em Belém, PA, constituída por 849 plantas. Nessa área, foram selecionadas 25 touceiras com base na produção de frutos. Seus frutos foram colhidos para a instalação de dois campos de produção de sementes: um no município de Santa Izabel, PA, e outro em Belém, PA, ambos em condições de terra firme. Nesses locais, transformados em área de produção de sementes básicas, foram eliminadas as plantas com desenvolvimento vegetativo inferior e aquelas sem perfilhamento. As principais características dessa cultivar são: bom perfilhamento, precocidade de produção, boa produção de frutos, frutos de coloração violácea e bom rendimento da parte comestível (15% a 25%). Como o programa de melhoramento é dinâmico, em breve, novas sementes melhoradas estarão disponíveis.Outras sementes (sem origem genética) estão disponíveis no mercado e podem ser utilizadas em plantios de terra firme, se a área de produção estiver nessas condições.


**2.9. Espaçamentos indicados e consórcios:**

Os espaçamentos indicados para o cultivo do açaizeiro solteiro visando à produção de frutos são baseados em observações de natureza prática, sendo os mais utilizados: 5 m x 5 m e 6 m x 4 m, com o manejo de 3 a 4 estipes por touceira. Mas outros espaçamentos vêm sendo empregados, como: 5 m x 3 m; 5 m x 4 m; 4 m x 4 m e 6 m x 6 m. Como a espécie é heliófila (necessita de luz para se desenvolver) os espaçamentos muito adensados não são recomendados, pois as plantas podem crescer muito e o tempo de colheita no estipe pode ser reduzido.  

Apesar das inúmeras possibilidades de espaçamento, o de 5 m x 5 m com manejo de 3 a 4 estipes/planta tem sido o mais indicado, por fornecer densidades de 1.200 plantas/ha e 1.600 plantas/ha, respectivamente. Esse espaçamento facilita a colheita, pelo menos até 10 anos após o plantio, como também propicia bom desenvolvimento no diâmetro dos estipes e reduz a altura das plantas, minimizando os riscos de tombamento pela ação de ventos fortes.
 
Os espaçamentos mais adensados também podem ocasionar baixas produtividades, em decorrência da competição entre as plantas por água e nutrientes. Por outro lado, espaçamentos mais abertos (6 m x 6 m) favorecem o crescimento de plantas daninhas, em particular nos primeiros 3 anos após o plantio, quando o sombreamento da superfície do solo pelos açaizeiros ainda é reduzido.
                                                                                                 
O cultivo solteiro deve ser visto com ressalvas, uma vez que o açaizeiro começa a produzir a partir do terceiro ano do plantio. Neste caso, os custos com a implantação só poderão ser abatidos nesta etapa, além de ser necessário efetuar um bom manejo do mato nas linhas e entrelinhas, para evitar a concorrência com as touceiras, onerando ainda mais os custos.
           
Uma forma de minimizar os custos é realizar o consórcio de culturas alimentares (milho, mandioca, caupi) ou fruteiras semiperenes (banana, mamão, maracujá, abacaxi) por propiciar renda ao produtor nos primeiros anos, além dos benefícios nos tratos culturais aplicados às culturas.
                                                                                                                            
Na associação com outras espécies perenes (cupuaçuzeiro, cacaueiro, cafeeiro), os espaçamentos recomendados são bem maiores, sendo os mais indicados 10 m x 5 m, 10 m x 10 m e 14 m x 7 m.Os consórcios recomendados para cultivo do açaizeiro em terra firme são: com espécies anuais (feião-caupi+milho+mandioca ou milho+feijão-caupi em rotação de culturas no primeiro ano) e semiperenes (maracujazeiro ou bananeira ou mamoeiro ou abacaxizeiro, até o terceiro ano), havendo inúmeros arranjos.    

Entre as fruteiras semiperenes, o consórcio mais promissor tem sido com o mamoeiro. No caso da bananeira, há informações de agressividade do seu sistema radicular, o que prejudica o desempenho das culturas consorciadas.O consórcio ou associação com culturas perenes (cupuaçuzeiro, cacaueiro, cafeeiro) pode permitir o plantio de espécies florestais para recuperar e valorizar o ecossistema.
                                                                                                      
Um dos consórcios mais interessantes dos pontos de vista biológico e econômico envolve o cupuaçuzeiro como cultura principal e o açaizeiro como cultura secundária. Nesse caso, o açaizeiro, que necessita de luz solar, deve ser usado como sombreamento definitivo do cupuaçuzeiro, espécie que suporta até 20 % de sombra sem afetar a produção. No consórcio do cupuaçuzeiro com o açaizeiro, a primeira espécie deve ser plantada no espaçamento de 5 m x 5 m e a segunda, no espaçamento de 10 m x 10 m.  No caso da associação, o espaçamento para as duas culturas é de 10 m x 5m, sendo o plantio realizado em linhas intercaladas.                                                                                                                                 
Na escolha de um consórcio ou associação, deve-se ficar atento para alguns fatores que podem interferir no sucesso, como: a direção nascente-poente, a arquitetura e envergadura da copa, a densidade da copa, a altura das plantas, a exigência de luz, a época, a frequência e a dosagem da adubação, o manejo das espécies e a época de produção.


**2.10. Germinação:**

O processo germinativo é relativamente rápido, porém desuniforme, iniciando-se a emergência das plântulas 22 dias após a semeadura e finalizando-se aos 48 dias, quando as sementes são semeadas logo após a remoção da polpa. No acompanhamento germinativo de sementes recém-colhidas de 25 progênies de açaizeiro desejáveis para a produção de frutos, foi constatada a variação de 17 a 28 dias para o início da germinação e de 33 a 60 dias para o término, com a porcentagem de germinação variando de 79% a 97,3%. A redução do grau de umidade, mesmo para níveis ainda altos, implica em comprometimento na porcentagem e no retardamento da germinação. Quando o grau de umidade é reduzido para valor em torno de 14,0%, as sementes perdem completamente a capacidade de germinação.


**2.11. Características do fruto e da polpa:**

O fruto do açaizeiro é uma drupa globosa ou levemente depressa, com diâmetro variando entre 1 cm e 2 cm e peso médio de 1,5 g. Quando maduro, pode apresentar coloração violácea ou verde, dependendo do tipo. O mesocarpo pouco polposo apresenta cerca de 1 mm de espessura, envolvendo um endocarpo volumoso e duro que acompanha, aproximadamente, a forma do fruto e contém, em seu interior, uma semente com embrião diminuto e endosperma abundante e ruminado. No entanto, podem ser encontrados frutos com mais de um embrião.

A parte comestível do fruto é constituída pelo epicarpo e mesocarpo, representando em média, 26,54% do seu peso. Mas há variações acentuadas, principalmente, em virtude do genótipo. A maior parte do fruto é representada pelo caroço ou endocarpo, o qual contém, em seu interior, uma semente com eixo embrionário diminuto e tecido de reserva rico em lipídios.


**2.12. Insetos-praga e doenças:**

A cultura do açaizeiro é atacada por várias pragas e doenças que podem causar grandes prejuízos. O conhecimento dos sintomas, danos causados, principais formas de contaminação e medidas de controle são determinantes para o sucesso da produção.


**2.12.1. Doenças:**

Alguns microrganismos (especialmente, fungos e bactérias) podem ocasionar problemas ao açaizeiro, principalmente, em mudas enviveiradas. Fungos, como é o caso da antracnose (Colletotrichum gloeosporoides), do carvão (Curvularia sp) e da helmintosporiose (Drechslera sp), têm sido registrados em viveiros de produção de mudas. O primeiro é o mais frequente, causando perdas de até 70% de mudas. A ocorrência de doenças está muito relacionada com a condição de manejo, especialmente em plantas mal nutridas, em locais com excesso de água nas mudas ou em viveiro com encharcamento e mudas muito adensadas.

Para o controle da antracnose, as mudas e plantas jovens devem ser mantidas com a adubação em dia e bem espaçadas, para permitir uma boa ventilação, especialmente no viveiro, afastadas uma das outras em pelo menos 10 cm. Caso esse procedimento não resolva, fazer pulverizações com os seguintes fungicidas: ziram ou captam ou thiram a 0,2% do produto comercial, em intervalos quinzenais. No entanto, tais produtos ainda não foram registrados no Ministério da Agricultura e do Abastecimento para uso no açaizeiro. Fungicidas à base de cobre não devem ser recomendados, pois podem causar fitotoxidez. Nas demais, recomenda-se um bom manejo: mudas adubadas, bem arejadas, evitando excesso de umidade.

Alguns distúrbios, provavelmente de origem fisiológica, têm sido constatados em açaizeiros, como a rachadura do estipe e dificuldade na abertura da inflorescência, com aspecto pendente, no início do ciclo produtivo. A rachadura caracteriza-se por uma ou mais fendas longitudinais que surgem nos estipes de comprimento em torno de 0,70 m, as quais se prolongam com o passar do tempo. Essas rachaduras servem de entrada para fungos saprofíticos, que ocasionam o apodrecimento e o tombamento do estipe. No caso do ramo florífero, tanto espatas recém-lançadas como próximas da abertura podem apresentar um aspecto de enfraquecimento no pedúnculo e no ráquis da inflorescência, ficando pendente. Em ambos os casos, o ramo florífero fica comprometido e a frutificação não ocorre. Deve-se então, eliminar os ramos floríferos que apresentarem esses sintomas e fazer uma boa irrigação e adubação. 

Sintomas frequentes, de encurtamento e enrugamento de folhas e folíolos, observados em plantas jovens e adultas não estão associados às doenças e sim relacionados com deficiência nutricional, principalmente de boro, e devem ser corrigidos com a aplicação de adubo (bórax) na dosagem recomendada no rótulo do produto.


**2.12.2. Insetos-praga:**

Diferentes espécies de insetos estão associadas ao açaizeiro nas fases adulta e de viveiro. Porém, ainda não há registros de perdas significativas nesses cultivos causadas por insetos-praga, o que tem refletido no relativo sucesso fitossanitário e viabilidade econômica dessa palmeira. Todavia, o aumento na área plantada com açaizeiro no País deverá alertar as autoridades fitossanitárias no que diz respeito à fiscalização, monitoramento e controle de eventuais populações de insetos-praga que poderão surgir em decorrência desse novo cenário de expansão da cultura no Brasil.

Insetos são capazes de atacar o estipe, os folíolos de folhas velhas, medianas e jovens (face superior e inferior) e as flechas do açaizeiro. Dessa forma, é recomendado o monitoramento frequente das áreas de cultivo para identificação dos primeiros focos de ocorrência da praga e imediata tomada de decisão para o controle da mesma.

A seguir, são apresentadas as principais espécies de insetos-praga capazes de comprometer cultivos de açaizeiro no Brasil.


**2.12.2.1. Pulgão-preto-do-coqueiro ou afídeo-das-palmáceas:**


**2.12.2.1.1. Caracterização:**

O pulgão-preto-das-palmáceas, Cerataphis brasiliensis (Hempel) [Hemiptera: Aphididae], apresenta corpo circular, esférico, com diâmetro de 1,5 mm a 2,0 mm, coloração preta, circundado por franja branca. São insetos pouco móveis, que se fixam em diferentes pontos da planta (normalmente flechas) e se alimentam, exclusivamente, da seiva das palmeiras. A presença desse inseto no açaizeiro é confirmada pela excreção de substância adocicada (“mela”) que atrai vespas, moscas e, principalmente, formigas, que atuam como protetoras contra a presença dos inimigos naturais da referida praga.


**2.12.2.1.2. Danos:**

O ataque de C. brasiliensis atrasa o desenvolvimento de mudas de açaizeiro em viveiros e de plantas recém-estabelecidas no campo, tornando-as raquíticas e com folhas amareladas, em virtude da sucção da seiva pelas ninfas e adultos desse afídeo. Indiretamente, a presença de C. brasiliensis em folhas de açaizeiro favorece o aparecimento de fumagina, que, ao encobrir a sua superfície foliar, prejudica a fotossíntese e dificulta o desenvolvimento da palmeira. Plantas em viveiros e no campo devem ser examinadas até completarem 2 anos de idade, visando à identificação da presença de fumagina e/ou pulgões vivos nas folhas mais novas e na flecha.


**2.12.2.1.3. Medidas de controle:**

Devem ser adotadas quando se constatar entre 30% e 35% das plantas amostradas com presença do inseto ou do fungo em 100 plantas avaliadas. Populações desse afídeo diminuem em campo durante o período chuvoso da região Amazônica brasileira. Ainda não existe inseticida registrado no Ministério da Agricultura, Pecuária e do Abastecimento (MAPA) para o controle de C. brasiliensis em açaizeiro. Portanto, o controle químico deve ser visto com ressalvas para esse inseto, pois trata-se de uma praga que tem sido eficientemente controlada na região Nordeste do Estado do Pará com o emprego de inseticidas botânicos à base de macerado de alho. Essa técnica, no entanto, ainda precisa passar pelo crivo científico.


**2.12.2.2. Saúvas:**


**2.12.2.2.1. Caracterização:**

As saúvas mais prejudiciais ao açaizeiro em viveiros são Atta laevigata (F. Smith), A. cephalotes L. e A. sexdens sexdens L. (Hymenoptera: Formicidae). São pragas de difícil controle, que atacam diversos cultivos. Podem ser encontradas em todos os estados brasileiros.


**2.12.2.2.2. Danos:**

Saúvas atacam o açaizeiro no viveiro ao longo de todo o ano, fato este que as enquadram como uma das principais pragas dessa cultura na fase jovem. O ataque das saúvas provoca o corte dos folíolos, podendo causar desfolhamento parcial ou total das mudas, provocando atraso no seu desenvolvimento ou, até mesmo, a morte das plantas.

A escolha do local para implantação do viveiro merece atenção especial, sendo recomendado que se evitem áreas próximas de matas (primárias ou secundárias), uma vez que é comum a presença de saúvas nesses ambientes.


**2.12.2.2.3. Medidas de controle:**

A instalação de viveiros de açaizeiros em áreas com histórico de ocorrência de saúvas exigirá, inicialmente, eliminação dos sauveiros e tratamento do solo para evitar o ataque às mudas.

O método de controle mais econômico e eficiente é o emprego de iscas granuladas, que podem ser também indicadas para o combate desses insetos em viveiros de açaizeiro. Além do controle químico, o controle biológico exercido pelos inimigos naturais, tais como fungos, nematóides, ácaros parasitas, formigas predadoras e coleópteros da família Scarabaeidae, tem demonstrado ser eficiente e capaz de reduzir populações da praga em diferentes ambientes.

**2.12.2.3. Moscas Brancas:**


**2.12.2.3.1. Caracterização:**

Duas espécies de moscas-brancas Aleurodicus cocois (Curtis) e Aleurothrixus floccosus (Maskell) [Hemiptera: Aleyrodidae] estão associadas ao açaizeiro no estado do Pará.

Adultos e imaturos de ambas as espécies vivem na face inferior dos folíolos do açaizeiro jovem, onde se alimentam e eliminam substância adocicada que propicia o aparecimento da fumagina. A. cocois caracteriza-se por formar colônias densas de ninfas e adultos, ocupando, na maioria das vezes, grande parte da área foliar das mudas de açaizeiro em viveiro e no campo. 

As espécies A. cocois e A. floccosus estão distribuídas por todo o território brasileiro, atacando grande número de fruteiras e diversas palmeiras no viveiro.


**2.12.2.3.2. Danos:**

Moscas-brancas se alimentam da seiva das plantas, provocando o amarelecimento inicial das mesmas, tornando-as debilitadas e, em seguida, cloróticas. Suas injúrias atrasam o desenvolvimento de açaizeiros, podendo, inclusive, causar a morte da palmeira em casos de ataques severos. Como plantas no viveiro ficam muito próximas uma das outras, esse inseto infesta facilmente mudas sadias, exigindo-se monitoramento frequente nesses ambientes.

**2.12.2.3.3. Medidas de controle:**

Por não existir inseticidas registrados no MAPA para o controle de A. cocois e A. floccosus em cultivos de açaizeiro, sugere-se que sejam realizadas inspeções a cada 10 ou 15 dias no viveiro ou no campo, visando detectar a ocorrência das referidas pragas. O emprego de óleos minerais, na concentração de 1%, e de inseticidas botânicos desponta como alternativa promissora para o controle desses insetos em cultivos de açaizeiro conduzidos por pequenos agricultores de base familiar da Amazônia.

**2.12.2.4. Gafanhotos:**


**2.12.2.4.1. Caracterização:**

Diferentes espécies de gafanhoto atacam o açaizeiro no viveiro e no campo. Dentre estas, a Eutropidacris cristata L. (Orthoptera: Acrididae), conhecida como gafanhoto-do-coqueiro ou tucurão, é a espécie mais comum e voraz. Os adultos possuem 110 mm de comprimento por 15 mm de largura; asas anteriores com 90 mm de comprimento e coloração verde-pardacenta e asas posteriores esverdeadas, com leve tonalidade azulada. É uma espécie polífaga e com ampla distribuição no Brasil, atacando diversas espécies vegetais.


**2.12.2.4.2. Danos:**

Diferentes espécies de gafanhotos atacam açaizeiro no viveiro e, dependendo da população, provocam danos também em plantas jovens no campo. Por causa da voracidade com que se alimentam e do grande tamanho das espécies, os gafanhotos são capazes de provocar atraso no desenvolvimento de palmeiras jovens de açaizeiro. A E. cristata é relatada, também, como uma praga de menor importância em coqueiro, quando esta cultura ainda está na fase jovem.

**2.12.2.4.3. Medidas de controle:**

O controle de gafanhotos desfolhadores em campo é difícil e oneroso, sendo às vezes ineficaz. Inexistem produtos inseticidas registrados no MAPA para o controle dessa praga em açaizeiro. Algumas táticas de controle podem ser empregadas com o intuito de impactar negativamente as populações desses herbívoros no campo, são elas: 
-catação manual e destruição dos indivíduos coletados em caso de infestações iniciais e populações pequenas; 
-estabelecimento de barreiras físicas e/ou químicas, particularmente para as espécies de gafanhotos migratórios; 
-emprego de inseticidas biológicos à base de entomopatógenos, particularmente fungos; 
-emprego de extratos vegetais com potencial biocida, como, por exemplo, o nim.


**2.12.2.5. Cochonilha ou escama-vírgula:**


**2.12.2.5.1. Caracterização:**

Em mudas de açaizeiro, a cochonilhas Mytilococcus (Lepidosaphis) beckii (Newman) (Hemiptera: Diaspididae) fixa-se ao longo da nervura principal da parte ventral dos folíolos e, em infestações mais severas, por todo o limbo foliar. É conhecida por “escama vírgula” em virtude do formato de seu corpo assemelhar-se a uma vírgula e apresentar coloração amarronzada. Formam pequenas colônias em açaizeiros e também atacam diversas culturas e plantas ornamentais. A sua ocorrência já foi relatada em todas as regiões do Brasil.


**2.12.2.5.2. Danos:**

M. beckii é um inseto sugador que se alimenta da seiva da planta. Dessa forma, as folhas do açaizeiro tornam-se inicialmente amareladas e, depois, cloróticas, provocando atraso no desenvolvimento das plantas.


**2.12.2.5.3. Medidas de controle:**

Não existem inseticidas registrados no Mapa para o controle desse inseto em açaizeiro. O emprego de inseticidas botânicos, conforme proposto para o afídeo das palmáceas, também desponta como promissor para o controle desse inseto em açaizeiro.


**2.12.2.6. Lagarta-desfolhadora:**


**2.12.2.6.1. Caracterização:**

Imaturo de Antaeotricha sp. (Lepidoptera: Elachistidae: Stenomatinae), apresenta corpo amarelo-claro com faixas longitudinais marrom-escuras, setas amarelo-claras e não muito curtas. As pupas são ligeiramente comprimidas dorsal e ventralmente, apresentando o tegumento marrom-avermelhado.
 
Adultos de Antaeotricha sp. apresentam asas amarelo-acinzentadas bem mais claras nas asas anteriores e mais escuras nas posteriores. Há dimorfismo sexual na ornamentação das asas anteriores de machos e fêmeas.


**2.12.2.6.2. Danos:**

Folhas de açaizeiro atacadas por Antaeotricha sp. ficam com a epiderme abaxial raspada e grande parte da área foliar perdida. Larvas nos primeiros estádios se alimentam raspando a epiderme da folha de açaí e as dos últimos estádios consomem toda a área foliar, deixando apenas a nervura principal e as das bordas da folha.


**2.12.2.6.3. Medidas de controle:**

Recomenda-se a catação manual de imaturos no início da infestação. Entretanto, para essa técnica ser eficiente, torna-se necessária a implantação do monitoramento das áreas.

Diferentes espécies de insetos-praga já foram observadas atacando plantas adultas de açaizeiro, particularmente, causando danos na base do coleto de plantas jovens [p. ex., a broca-do-bulbo-das-palmáceas Strategus sp. (Coleoptera: Scarabeidae)]; no estipe de açaizeiros adultos [p. ex., o bicudo-das-palmáceas Rhynchophorus palmarum L. (Coleoptera: Curculionidae) e a broca-da-coroa-foliar-do-dendezeiro Eupalamides cyparissias cyparissias Fabricius (Lepidoptera: Castniidae)], e na parte aérea [p. ex., desfolhadoras em geral, como Opsiphanes invirae Huebner (Lepidoptera: Nymphalidae)] das plantas. Entretanto, até o momento, não há registros da ocorrência de surtos dessas pragas em cultivos de açaizeiro provocados pelo aumento da densidade populacional das mesmas.


**2.13. Estimativas de produtividade:**

Os dados sobre produtividade de frutos do açaizeiro são ainda inconsistentes. Isto se deve ao pouco conhecimento de práticas culturais e de manejo mais eficientes para a cultura. São apresentadas as estimativas para produtividades do açaizeiro com base na produção da cultivar BRS-Pará para cultivo solteiro e consorciado.

Dentro de uma touceira, a planta-mãe é a primeira a entrar em produção por volta do quarto ano do plantio, sendo esta produção insignificante nos dois primeiros anos, crescendo consideravelmente a partir do sexto ano após o plantio. Em pomar implantado em Latossolo Amarelo textura leve, no espaçamento de 6 m x 6 m, manejado com três plantas por touceira, com adubação orgânica e mineral, observaram-se incrementos significativos na produção até o 11º ano, quando a produção atingiu 42,2 kg de frutos/touceira/ano, decrescendo nos anos subsequentes.

Na Coleção de Germoplasma de Açaizeiro da Embrapa Amazônia Oriental, também implantada em Latossolo Amarelo textura média, no espaçamento de 5 m x 3 m, sem desbaste de estipes, a produção, 10 anos após o plantio, foi altamente variável, de 0,1 kg a 50,9 kg de frutos/touceira/ano, evidenciando a influência do genótipo e da procedência.

Em açaizais nativos, manejados para a produção de frutos, com densidade de 1.500 plantas/ha, com cerca de 53% delas em fase de produção, foi registrada produtividade de até 9.000 kg de frutos/ha. Por outro lado, para açaizais não manejados, a produtividade foi de apenas 4.500 kg de frutos/ha, em decorrência da baixa densidade de plantas.


**2.14. Cultivo do açaizeiro em terra firme:**

O plantio de açaizeiro em áreas de terra firme representa excelente alternativa para a recuperação de áreas alteradas, além de reduzir a pressão sobre o frágil ecossistema de várzea, evitando sua transformação em bosques homogêneos dessa palmeira. Outra vantagem no plantio de açaizeiros em áreas de terra firme está relacionada com a facilidade de transporte rodoviário e de beneficiamento, de forma mais rápida, sem depender do transporte fluvial mais lento


**2.15. Custo do sistema de irrigação por microaspersão:**

O custo de uma lata de fruto de açaí irrigado por aspersão é de R$ 13,78, considerando-se uma produtividade de 120 latas/ha. Com a estabilização da produção, em 180 latas/ha, este custo decresce para R$ 10,57/lata, permitindo dobrar a receita líquida. Chama-se a atenção que este custo está elevado em comparação com o fruto do açaí produzido durante a safra nas várzeas, mas, quando se aproveita o nicho de mercado durante a entressafra, esse custo se torna vantajoso.

Entre os itens de custos mais importantes, destaca-se o consumo de combustível do trator, o custo do transporte, o consumo de energia elétrica na irrigação, a mão de obra e a depreciação do conjunto de motores-bomba, trator e equipamentos. É possível, ainda, reduzir os custos via aumento da produtividade dos frutos e pela maior eficiência no uso dos equipamentos agrícolas. O grande problema está relacionado com o custo da tarifa da energia elétrica, que, pelo desconhecimento da concessionária de energia elétrica, conduz à desconfiança dos produtores em investirem em equipamentos para aferição do consumo para tarifas reduzidas. 


**2.16. Armazenamento das sementes:**

As sementes do açaizeiro são classificadas como recalcitrantes, ou seja, perdem ou reduzem drasticamente o poder germinativo com a redução da umidade. Além da sensibilidade ao dessecamento, as sementes também não suportam baixas temperaturas, havendo comprometimento da viabilidade quando mantidas em ambientes com temperaturas iguais ou inferiores a 15 °C. Em decorrência desses fatos, a conservação do poder germinativo das sementes não pode ser efetuada pelos processos convencionais de armazenamento, que têm como pré-requisitos básicos a secagem e o armazenamento em temperaturas baixas.                                                                                                                                                           
Na conservação de sementes de açaí em curtos períodos de armazenamento, em condições de ambiente natural da Amazônia, ou quando se deseja transportar as sementes para locais distantes, podem ser usados dois sistemas. No primeiro, as sementes são estratificadas ou misturadas em substrato úmido, que pode ser tanto serragem como vermiculita, e acondicionadas em caixas de madeira, isopor ou em sacos de plástico. Areia ou apenas terriço não são recomendados como substrato, por apresentarem maior densidade. Nesse sistema, as sementes são dispostas em camadas alternadas com o substrato úmido ou simplesmente misturadas com este e acondicionadas em caixas de madeira, isopor ou em sacos de plástico. Na Embrapa Amazônia Oriental tem-se adotado a proporção volumétrica de uma parte de sementes para uma parte de substrato.
                                                                                                                                                     
No segundo sistema, as sementes são embaladas em sacos de plástico com capacidade para 4 kg de sementes, havendo necessidade de tratamento com fungicida e de enxugamento superficial, de tal forma que o teor de água das sementes seja reduzido para 35,0%. Em ambos os casos, o período de armazenamento não deve ultrapassar 20 dias, pois muitas sementes poderão completar a germinação dentro da embalagem, o que dificulta a retirada das mesmas e condiciona o aparecimento de plântulas anormais.                                                                                                                                                                                         
Entretanto, resultados de pesquisas mais recentes indicaram que a secagem parcial das sementes de açaí até 37,4% de água e o armazenamento em ambiente com temperatura constante de 20 ºC conservam satisfatoriamente as sementes por até 240 dias, ampliando o período de armazenamento da espécie. Pode-se observar o efeito negativo da temperatura de armazenamento em ambiente a 15 ºC e 10 ºC, durante 12 meses.