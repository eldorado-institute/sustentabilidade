import pandas as pd
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'data/tratamento_dados/tratamento_dados_agro/producao_estadual_anual_acai.csv'
OUTPUT_DIR = 'knowledge/dados_prod_agricola'
OUTPUT_FILENAME = 'taxa_crescimento_producao_acai.csv'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, OUTPUT_FILENAME)

def calcular_taxa_crescimento():
    """
    Calcula a taxa de crescimento da produção de açaí, salva em CSV e exibe os resultados.
    """
    try:
        # Carregar os dados.
        df = pd.read_csv(INPUT_FILE)

        # --- 1. Calcular a produção total por ano ---
        # O groupby().sum() garante a agregação correta caso o arquivo de entrada não esteja pré-agregado.
        producao_total_anual = df.groupby('Ano')['Producao_Total_Estado_toneladas'].sum().reset_index()

        # Ordenar os dados por ano para garantir que os cálculos de crescimento sejam corretos.
        producao_total_anual = producao_total_anual.sort_values('Ano').reset_index(drop=True)

        # --- 2. Calcular o crescimento percentual ano a ano ---
        # A função pct_change() calcula a variação percentual entre o elemento atual e o anterior.
        # Multiplicamos por 100 para ter o resultado em porcentagem.
        producao_total_anual['Crescimento Anual (%)'] = producao_total_anual['Producao_Total_Estado_toneladas'].pct_change() * 100

        # Arredondar para 2 casas decimais para melhor visualização
        producao_total_anual['Crescimento Anual (%)'] = producao_total_anual['Crescimento Anual (%)'].round(2)

        # --- 3. Salvar os resultados em CSV ---
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        producao_total_anual.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig')
        print(f"\nArquivo '{OUTPUT_FILENAME}' salvo com sucesso em '{OUTPUT_FILE}'.")

        # --- 4. Exibir resultados no console ---
        print("\n--- Tabela de Produção Total e Crescimento Ano a Ano ---")
        print(producao_total_anual.to_string())
        print("\n" + "="*60 + "\n")

        # --- 5. Calcular e exibir a Taxa de Crescimento Anual Composta (CAGR) ---
        if len(producao_total_anual) > 1:
            # Pegar o primeiro e o último ano com dados
            primeiro_ano_data = producao_total_anual.iloc[0]
            ultimo_ano_data = producao_total_anual.iloc[-1]

            valor_inicial = primeiro_ano_data['Producao_Total_Estado_toneladas']
            valor_final = ultimo_ano_data['Producao_Total_Estado_toneladas']
            num_anos = ultimo_ano_data['Ano'] - primeiro_ano_data['Ano']

            # Evitar divisão por zero se o valor inicial for 0 ou se não houver período de tempo
            if valor_inicial > 0 and num_anos > 0:
                cagr = ((valor_final / valor_inicial) ** (1 / num_anos)) - 1
                cagr_percent = cagr * 100

                print(f"--- Taxa de Crescimento Anual Composta (CAGR) ---")
                print(f"Período de Análise: De {int(primeiro_ano_data['Ano'])} a {int(ultimo_ano_data['Ano'])} ({int(num_anos)} anos)")
                print(f"Produção Inicial: {valor_inicial:,.2f} toneladas")
                print(f"Produção Final:   {valor_final:,.2f} toneladas")
                print(f"CAGR: {cagr_percent:.2f}% ao ano")
                print("\nIsso significa que, em média, a produção cresceu a uma taxa de "
                      f"{cagr_percent:.2f}% a cada ano durante este período.")
            else:
                print("Não foi possível calcular o CAGR. Verifique se há mais de um ano de dados e se a produção inicial é maior que zero.")
        else:
            print("Não há dados suficientes para calcular a taxa de crescimento (necessário mais de um ano).")

    except FileNotFoundError:
        print(f"Erro: O arquivo de entrada não foi encontrado em '{INPUT_FILE}'.")
        print("Por favor, verifique o caminho e o nome do arquivo.")
    except KeyError as e:
        print(f"Erro: Uma coluna esperada não foi encontrada: {e}.")
        print("Por favor, verifique se os nomes das colunas no seu CSV são 'Ano' e 'Producao_Total_Estado_toneladas'.")

if __name__ == '__main__':
    calcular_taxa_crescimento()
