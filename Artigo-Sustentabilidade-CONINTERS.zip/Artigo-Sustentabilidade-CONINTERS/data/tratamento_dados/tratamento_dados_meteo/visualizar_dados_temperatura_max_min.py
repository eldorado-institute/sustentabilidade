import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'knowledge/dados_meteorologicos/temperaturas_anuais_max_min.csv'

# Define o renderizador padrão para abrir no navegador
pio.renderers.default = 'browser'

def visualizar_temperaturas_max_min_anuais():
    """
    Cria um gráfico de linha interativo com os dados anuais de temperatura máxima e mínima,
    exibindo os valores no gráfico.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'gerar_dados_temperatura_max_min.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)

    # --- Criação do Gráfico ---
    print("Gerando gráfico com Plotly...")
    fig = go.Figure()

    # Adiciona a linha de Temperatura Máxima
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Temperatura_Maxima_C'],
        name='Temperatura Máxima Média Mensal (°C)',
        mode='lines+markers+text',
        line=dict(color='crimson', dash='solid'),
        hovertext=df['Mes_Maxima'],
        text=df['Temperatura_Maxima_C'].round(1).astype(str) + ' - ' + df['Mes_Maxima'],
        textposition='top center',
        textfont=dict(size=10, color='dimgray'),
        hovertemplate='<b>Ano</b>: %{x}<br><b>Máxima</b>: %{y:.1f}°C<br><b>Mês</b>: %{hovertext}<extra></extra>'
    ))

    # Adiciona a linha de Temperatura Mínima
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Temperatura_Minima_C'],
        name='Temperatura Mínima Média Mensal (°C)',
        mode='lines+markers+text',
        line=dict(color='blue', dash='dash'),
        hovertext=df['Mes_Minima'],
        text=df['Temperatura_Minima_C'].round(1).astype(str) + ' - ' + df['Mes_Minima'],
        textposition='bottom center',
        textfont=dict(size=10, color='dimgray'),
        hovertemplate='<b>Ano</b>: %{x}<br><b>Mínima</b>: %{y:.1f}°C<br><b>Mês</b>: %{hovertext}<extra></extra>'
    ))

    # --- Customização do Layout ---
    fig.update_layout(
        title={'text': '<b>Evolução Anual da Temperatura Máxima e Mínima no Amazonas</b>', 'y':0.9, 'x':0.5, 'xanchor': 'center', 'yanchor': 'top'},
        xaxis_title='<b>Ano</b>',
        yaxis_title='<b>Temperatura Média Mensal (°C)</b>',
        plot_bgcolor='white',
        font=dict(family="Arial, sans-serif", size=12, color="black"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    fig.update_xaxes(tickmode='linear', gridcolor='lightgray', linecolor='black')
    fig.update_yaxes(gridcolor='lightgray', linecolor='black')

    # --- Exibição do Gráfico ---
    print("Exibindo gráfico interativo. Uma nova aba será aberta no seu navegador.")
    fig.show()

if __name__ == '__main__':
    visualizar_temperaturas_max_min_anuais()

