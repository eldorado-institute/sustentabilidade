import pandas as pd
import glob
import io

arquivos = glob.glob('data/dados-meteorologicos-INMET/dados_pluviometricos_INMET/*.csv')
dfs = []

for arquivo in arquivos:
    # Arquivos de fontes brasileiras como o INMET costumam usar a codificação 'latin-1'
    try:
        with open(arquivo, 'r', encoding='latin-1') as f:
            linhas = f.readlines()
    except Exception as e:
        print(f"Erro ao ler o arquivo {arquivo}: {e}")
        continue

    # Extrai contexto
    contexto = {}
    # Aumentado para 10 por segurança, caso o cabeçalho seja maior
    for linha in linhas[:10]:
        if ':' in linha:
            chave, valor = linha.strip().split(':', 1)
            contexto[chave.strip()] = valor.strip()

    # Encontra o índice do cabeçalho dos dados
    idx_dados = None
    for i, linha in enumerate(linhas):
        # Usar .upper() torna a busca insensível a maiúsculas/minúsculas
        if 'DATA MEDICAO;' in linha.upper():
            idx_dados = i
            break

    if idx_dados is None:
        print(f"Aviso: Cabeçalho 'Data Medicao;' não encontrado em {arquivo}. Pulando.")
        continue

    # --- MUDANÇA PRINCIPAL ---
    # 1. Juntar as linhas de dados em uma única string
    dados_csv_string = ''.join(linhas[idx_dados:])

    # 2. Usar io.StringIO para tratar a string como um arquivo
    # Isso é mais robusto que usar skiprows no arquivo original
    df = pd.read_csv(io.StringIO(dados_csv_string), sep=';', decimal=',')

    # 3. Remover colunas completamente vazias que podem ser criadas por erros de formatação
    # O arquivo de exemplo mostra uma coluna "Unnamed: 5" que será removida com isso
    df.dropna(axis='columns', how='all', inplace=True)

    # Adiciona contexto como colunas
    for chave, valor in contexto.items():
        df[chave] = valor

    # Remove coluna de pressão atmosférica
    col_pressao = [col for col in df.columns if 'PRESSAO ATMOSFERICA' in col.upper()]
    if col_pressao:
        df = df.drop(columns=col_pressao)
    dfs.append(df)

if dfs:
    df_final = pd.concat(dfs, ignore_index=True)
    
    # Renomear colunas para nomes mais simples e sem caracteres especiais
    df_final.rename(columns={
        'Data Medicao': 'data_medicao',
        'NUMERO DE DIAS COM PRECIP. PLUV, MENSAL (AUT)(nÃºmero)': 'dias_com_precipitacao',
        'PRECIPITACAO TOTAL, MENSAL (AUT)(mm)': 'precipitacao_total_mm',
        'TEMPERATURA MEDIA, MENSAL (AUT)(Â°C)': 'temperatura_media_c',
        'Nome': 'estacao_nome',
        'Codigo Estacao': 'estacao_codigo',
        'Latitude': 'latitude',
        'Longitude': 'longitude',
        'Altitude': 'altitude',
        'Situacao': 'situacao',
        'Data Inicial': 'data_inicial',
        'Data Final': 'data_final'
    }, inplace=True)

    # Remove as linhas onde tanto a precipitação quanto a temperatura estão ausentes
    linhas_antes = len(df_final)
    df_final.dropna(subset=['precipitacao_total_mm', 'temperatura_media_c'], how='all', inplace=True)
    linhas_depois = len(df_final)
    print(f"Verificação de dados ausentes: {linhas_antes - linhas_depois} linhas removidas.")

    # Remove colunas desnecessárias
    cols_to_drop = ['situacao', 'estacao_codigo']
    if 'Periodicidade da Medicao' in df_final.columns:
        cols_to_drop.append('Periodicidade da Medicao')
    df_final = df_final.drop(columns=cols_to_drop)

    # --- NOVA LÓGICA DE SAÍDA ---
    # Colunas de dados que variam por linha
    data_cols = ['data_medicao', 'dias_com_precipitacao', 'precipitacao_total_mm', 'temperatura_media_c']
    
    # Colunas de metadados (constantes por estação)
    meta_cols = ['estacao_nome', 'latitude', 'longitude', 'altitude', 'data_inicial', 'data_final']

    # Agrupar por estação
    grouped = df_final.groupby('estacao_nome')

    output_path = 'dados_meteorologicos_compilados.txt'
    with open(output_path, 'w', encoding='utf-8') as f:
        station_blocks = []
        for station_name, station_df in grouped:
            block_writer = io.StringIO()
            block_writer.write(f"ESTACAO: {station_name}\n")
            
            # Escreve os metadados uma vez
            metadata = station_df.iloc[0]
            block_writer.write("METADADOS:\n")
            block_writer.write(f"- Latitude: {metadata['latitude']}\n")
            block_writer.write(f"- Longitude: {metadata['longitude']}\n")
            block_writer.write(f"- Altitude: {metadata['altitude']}\n")
            block_writer.write(f"- Período dos Dados: {metadata['data_inicial']} a {metadata['data_final']}\n\n")

            # Escreve os dados de medição
            block_writer.write("DADOS:\n")
            station_data_df = station_df[data_cols]
            # Converte para CSV string sem o índice e com cabeçalho, garantindo que o separador decimal seja '.'
            csv_data = station_data_df.to_csv(sep=';', index=False, header=True, decimal='.', lineterminator='\n')
            block_writer.write(csv_data)
            
            station_blocks.append(block_writer.getvalue())

        # Junta os blocos com um separador
        f.write("\n---\n\n".join(station_blocks))

    print(f"Arquivo '{output_path}' gerado com sucesso!")
else:
    print("Nenhum dado foi processado.")