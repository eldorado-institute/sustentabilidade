# Dados Botânicos do Açaí

# 1. Pré-Produção

O item pré-produção trata de temas relacionados à importância socioeconômica da cultura do açaí bem como às características da espécie e relações com o meio ambiente.

## 1.1. Importância Socioeconômica

### 1.1.1. Mercado externo

Observa-se que o açaí lidera a economia da fruticultura, tendo o Estado do Pará o epicentro da produção e processamento. Em 2006, esse estado exportou 8 mil toneladas de polpa da fruta. A demanda por açaí foi estimada em 300 mil toneladas de polpa em 2006, podendo se estabilizar em 500 mil toneladas nos próximos 10 anos, mantendo um fluxo de exportação de 60 mil toneladas por ano e o restante para consumo no mercado brasileiro.

De 2004 a 2008, o Estado do Pará mostrou um crescimento constante na exportação de açaí, como é evidenciado pelo valor comercializado, que obteve um crescimento de US$ 1.982.791 em 2004 para US$ 20.738.868 em 2008, um aumento de 1.046%, embora a quantidade exportada tenha crescido apenas 560% no mesmo período. Isso ocorreu em decorrência do aumento do preço médio em cerca de 187% nesse intervalo, aumentando, assim, a lucratividade da exportação do produto. Para 2009, todos esses valores aumentaram, e o valor comercializado, a quantidade comercializada e o preço médio, no período de janeiro a julho de 2008 e 2009, revelaram aumentos de 47,05%, 41,21% e 4,16%, respectivamente.

Os principais importadores do açaí do Estado do Pará são:
- **Estados Unidos:** 92% da quantidade total em toneladas e do valor comercializado em 2008 (equivalente a 7 t e US$ 19 milhões). O país experimentou um crescimento de 1.449% dos valores de importação no período de 2004 a 2008.
- **Japão e Países Baixos:** Ocupam as próximas posições, com cerca de 2,5% dos importadores cada.
- **Reino Unido:** Embora com baixa participação (0,56%), o mercado parece estar em franca expansão, com crescimento de valores superior a 17.000%.

Para as estimativas de janeiro a julho de 2008 e 2009, no entanto, o único país que demonstrou aumento foram os Estados Unidos (valor 73,7% maior e 61,4% de toneladas a mais). Em contrapartida, Japão, Reino Unido, Suécia e Austrália mostraram queda superior a 74% nos valores e 72,8% em quantidade. Como ponto positivo, observa-se que novos países tornaram-se importadores em 2009, como Espanha, Israel, Angola, Porto Rico e Turquia, embora ainda sejam mercados incipientes.

### 1.1.2. Locais de Produção do açaí

O açaizeiro também se constitui na principal fonte de matéria-prima para a agroindústria de palmito no Brasil. Sua maior concentração ocorre em solos de várzeas e igapós do estuário amazônico, com área estimada em 1 milhão de hectares, mas pode ser encontrado como espécie componente do ecossistema de floresta natural ou em forma de maciços conhecidos como açaizais.

A produção de açaí extrativo ocorre em áreas de ocorrência espontânea do gênero Euterpe, em solos úmidos ou às margens de rios e lagos nos seguintes estados:
- Acre
- Amapá
- Amazonas
- Pará
- Roraima
- Rondônia
- Maranhão

No entanto, é na região do estuário do Rio Amazonas (Amapá e Pará) que se encontram as maiores e mais densas populações naturais, principalmente em solos de várzeas.

Inicialmente, a exploração era exclusivamente extrativa. Desde a década de 1990, devido à valorização comercial, foram implementadas ações de manejo de açaizais nativos e cultivos em várzea e terra firme, em sistema solteiro ou consorciado.

O açaí cultivado está se expandindo, principalmente, em áreas de terra firme de vários estados da Amazônia e no sul da Bahia, com predominância dessa expansão no Estado do Pará.

### 1.1.3. Mercado Nacional

O açaí é um produto tradicional na dieta da população amazônica. Até a década de 1990, era consumido principalmente pela população de baixo poder aquisitivo devido ao preço acessível e valor nutritivo.

No início dos anos 1990, o consumo expandiu-se rapidamente, alcançando as classes de maior renda na Amazônia. Concomitantemente, cresceu a demanda nacional (São Paulo, Rio de Janeiro, Nordeste) e internacional (EUA, União Europeia) pela polpa congelada.

O processo de urbanização também influenciou o aumento do consumo, pois os migrantes do interior mantiveram o hábito de consumir açaí nas cidades.

O perfil do consumidor varia:
- **Região Metropolitana de Belém:** Prefere o vinho ou suco (74,6%).
- **Outros estados brasileiros:** Consumo preferencial com outros alimentos (granola, guaraná, frutas).
- **Mercado internacional:** Variações de polpa congelada com xarope de guaraná e outras frutas, processadas conforme especificações dos compradores.

Consumidores das regiões tradicionais (Pará, Amapá, Maranhão) geralmente não aceitam a polpa congelada, preferindo o produto processado no dia do consumo.

### 1.1.4. Políticas e legislação

Em agosto de 2007, o preço do açaí caiu 33,7% devido à redução no consumo após mortes por mal-de-chagas. Em outubro de 2007, estabelecimentos comerciais firmaram um Termo de Ajustamento de Conduta (TAC) com o Ministério Público para se adequar às normas de higiene da Lei 8.918/94, visando evitar contaminações.

O MAPA definiu o Regulamento Técnico para Padrões de Identidade e Qualidade da Polpa de Açaí (BRASIL, 2000). Em 2005, a RDC nº 218 instituiu o Regulamento Técnico de Procedimentos Higiênico-Sanitários para Manipulação de Alimentos e Bebidas com Vegetais, abrangendo toda a cadeia de preparo e comercialização para evitar doenças transmitidas por alimentos.

No Pará, foi criado o Programa Estadual da Qualidade do Açaí, com a participação de diversas instituições para capacitar batedores de açaí em boas práticas, seguindo as normas do Programa Alimento Seguro (PAS).

### 1.1.5. As exportações de frutas, polpas e sucos no Estado do Pará

O valor das exportações de frutas, polpas e sucos do Pará cresceu de US$ 6,42 milhões (5.418 toneladas) em 2004 para US$ 27,97 milhões (11.350 toneladas) em 2009. Em 2009, a exportação de castanha e cacau somou mais de US$ 7,9 milhões, totalizando US$ 35,16 milhões com as frutas. No Amapá, o arranjo produtivo do açaí movimentou R$ 177 milhões, correspondendo a 5% do total das divisas de exportação em 2009.

## 1.2. Características da espécie e relações com o meio ambiente

### 1.2.1. Biologia Reprodutiva

- **Início da fase reprodutiva:** 4 a 5 anos após a germinação.
- **Floração e frutificação:** Ocorrem o ano todo.
- **Pico de florescimento:** Janeiro a maio.
- **Pico de frutificação:** Agosto a dezembro (pode variar com local e ecotipo).
- **Dormência de sementes:** Não apresenta.
- **Classificação ecológica:** Planta heliófila (gosta de sol).
- **Idade de reprodução:** 5 a 10 anos.
- **Tempo de vida útil:** 10 a 25 anos.

### 1.2.2. Relações com o Clima

O açaizeiro ocorre naturalmente em áreas alagadas (várzea e igapó), mas adapta-se bem à terra firme com boa distribuição de chuvas. É típico de clima tropical chuvoso e adaptado à Amazônia, ocorrendo nos tipos climáticos de Köppen: Afi, Ami e Awi. A luz é um fator limitante para o bom desenvolvimento.

- **Características de espécie secundária:** Não apresenta dormência de sementes, regenera-se por banco de plântulas e tolera sombreamento apenas no estágio juvenil.
- **Condições ideais (Belém, PA - clima Afi):** Temperatura média de 25,9 ºC, precipitação de 2.761 mm/ano. Apresenta excelente desenvolvimento e alta produtividade.
- **Condições boas (Santarém, PA):** Temperatura média de 26 ºC, precipitação de 2.096 mm/ano. Apresenta bom desenvolvimento, mas produtividade menor.
- **Limite térmico (litoral paulista):** Pode ser cultivado com temperatura média anual de 21 ºC, mas não se adapta a áreas mais altas e frias.

### 1.2.3. Relações com o Solo

Ocorre naturalmente em solos eutróficos (ricos em nutrientes) e distróficos (pobres em nutrientes), predominando em Gleissolos de várzeas do estuário (ácidos, argilo-siltosos, boa fertilidade).

É uma espécie dominante em florestas de várzea, pois possui mecanismos adaptativos para sobreviver em solos com baixo oxigênio, como:
- Raízes que emergem do estipe acima do solo.
- Presença de lenticelas.
- Presença de aerênquimas nas raízes.

Em terra firme, tem bom desenvolvimento em Latossolos amarelos de textura média a pesada. Prefere ambientes de várzea e igapós, em solos hidromórficos tipo Gley pouco úmico.

### 1.2.4. Características Botânicas do Açaí

#### 1.2.4.1. Frutos

Cada fruto é uma drupa globosa. Contém mesocarpo fino (1-2 mm), de coloração variável. A parte comestível (epicarpo e mesocarpo) representa de 7% a 25% do fruto. A maior parte do fruto é o endocarpo fibroso, que contém uma semente rica em lipídios.

#### 1.2.4.2. Sementes

A semente possui endocarpo duro, embrião diminuto e endosperma abundante. É de comportamento recalcitrante (não tolera secagem). A principal característica do açaizeiro é a emissão de perfilhos na base do estipe principal, formando uma touceira.

# 2. Produção

Este item aborda aspectos do cultivo do açaizeiro em terra firme, incluindo propagação, plantio, tratos culturais, pragas, doenças, colheita e custos.

## 2.1. Coeficientes técnicos, custos e rentabilidade

Para 1 ha de açaizeiro em terra firme (espaçamento 5m x 5m):
- **Anos 1-3:** Apenas custos, sem receita.
- **Ano 4:** Produção de 72 rasas, receita de R$ 1.800,00 (a R$ 25,00/rasa), sem benefício líquido.
- **Ano 5:** Benefício líquido previsto de R$ 264,00.
- **Ponto de equilíbrio:** A partir do sexto ano.

## 2.2. Escolha e preparo de área para plantio

O cultivo deve ser indicado para áreas já exploradas, degradadas ou com vegetação secundária de pequeno porte. Áreas de vegetação primária devem ser evitadas. O preparo consiste em roçagem, piqueteamento, controle de ervas, abertura de covas e plantio.

O açaizeiro pode ser plantado em sistema solteiro, consorciado ou associado a outras culturas. O consórcio com culturas alimentares (milho, feijão) é a melhor opção para garantir renda rápida ao produtor.

## 2.3. Custo do sistema de irrigação por aspersão

A produtividade média do sistema irrigado é de 120 latas/ha no quinto ano, podendo atingir 4,5 t/ha (321 latas) na estabilização. Em 2006, o custo de uma lata de açaí irrigado era de R$ 13,78 (com produtividade de 120 latas/ha), caindo para R$ 10,57/lata com a estabilização da produção em 180 latas/ha.

## 2.4. Métodos de propagação

Pode ser propagado por via sexuada (sementes) e assexuada (perfilhos). A propagação por sementes é a mais comum. A assexuada, por perfilhos, é promissora para obter plantios uniformes, mas é demorada e com baixos índices de sobrevivência, não sendo indicada para escala comercial atualmente.

### 2.4.1. Propagação assexuada

A propagação vegetativa por perfilhos é valiosa para o melhoramento genético. Contudo, a técnica ainda é incipiente, com taxas de enraizamento variando de 30% a 60%. A propagação *in vitro* tem tido algum sucesso com embriões zigóticos, mas não há protocolos para tecidos somáticos.

### 2.4.2. Propagação sexual (sementes)

A estrutura usada é o endocarpo, que contém a semente. O peso do fruto varia (0,8 g a 2,3 g), resultando em 435 a 1.250 sementes por quilo (média de 667 sementes/kg). Sementes de frutos recém-colhidos têm alta germinação (>90%).

### 2.4.3. Semeadura e formação de mudas

As sementes podem ser semeadas em sementeiras ou diretamente em sacos de polietileno. Devem ser obtidas de frutos recém-colhidos e despolpados.

#### 2.4.3.1. Formação das mudas

As mudas permanecem no viveiro por 6 a 8 meses. Devem ser mantidas em viveiros com 50% de sombra. A Comissão Estadual de Sementes e Mudas do Pará estabelece padrões para mudas fiscalizadas, que devem ter:
- Altura uniforme (40-60 cm), aspecto vigoroso.
- Mínimo de cinco folhas ativas.
- Idade de 4 a 8 meses.
- Sistema radicular bem desenvolvido.
- Isenção de pragas e doenças.

#### 2.4.3.2. Semeadura

- **Semeadura direta em sacos:** Recomendada para poucas mudas (500-1.000).
- **Semeadura em sementeira:** Recomendada para muitas mudas (>5.000), pois economiza mão de obra e permite seleção.

## 2.5. Plantio

O plantio em terra firme deve ser feito no início do período chuvoso, em covas de 40x40x40 cm, previamente adubadas. As mudas devem ser plantadas no centro das covas, cobrindo o torrão até o coleto. O uso de cobertura morta e sombreamento nos primeiros meses é fundamental. Com irrigação, o plantio pode ser feito em qualquer época.

## 2.6. Colheita

A colheita ocorre de 5 a 6 meses após a fecundação, quando os frutos estão roxo-escuros ou verde-escuros. É uma operação difícil e onerosa, realizada pela manhã para evitar a debulha dos frutos. Exige escaladores habilidosos, que podem colher de 150 a 200 kg de frutos em 6 horas. Equipamentos como varas de colheita estão sendo testados para melhorar a eficiência. Os frutos devem ser acondicionados em caixas de plástico ou cestos de fibras (paneiros).

## 2.7. Tratos Culturais

Aborda nutrição, adubação, manejo de perfilhos, limpeza, controle de mato, irrigação e manejo de inflorescências.

### 2.7.1. Nutrição e Adubação

A análise de solo é indispensável. Estudos sobre nutrição ainda são incipientes. A ordem de interferência dos macronutrientes na produção de matéria seca é: K > Mg > P > N > Ca > S.

#### 2.7.1.1. Adubação em cultivo solteiro e consorciado

As recomendações variam se o cultivo é solteiro ou consorciado com culturas como maracujazeiro, bananeira, mandioca ou cupuaçuzeiro, envolvendo adubação química (N.P.K) e orgânica (esterco).

#### 2.7.1.1.1. Em consórcio com maracujazeiro, bananeira ou mandioca

Recomenda-se adubação específica para o açaizeiro e para a cultura consorciada, com diferentes formulações e dosagens ao longo dos anos.

#### 2.7.1.1.2. Em cultivo consorciado com cupuaçuzeiro

Recomendações detalhadas de adubação para ambas as culturas, com N.P.K, FTE Br 13 e cama de aviário.

#### 2.7.1.1.3. Em cultivo solteiro

Aplicações de N.P.K e esterco em dosagens crescentes do primeiro ao quarto ano. A partir da fase reprodutiva, a adubação potássica é aumentada.

### 2.7.2. Necessidades de irrigação

A disponibilidade de água é primordial. O déficit hídrico reduz as atividades fisiológicas. Em terra firme, o cultivo deve ser em áreas de clima Afi, ou com irrigação suplementar em climas Ami e Awi. A irrigação por microaspersão ou gotejamento é recomendada nos primeiros anos, e por aspersão na fase produtiva. A falta de água causa sintomas como não abertura dos folíolos, queda de folhas e pode levar à morte da planta. A irrigação permite a produção na entressafra, quando os preços são mais altos.

### 2.7.3. Manejo de inflorescências

Para produzir na entressafra (primeiro semestre, preços melhores), pode-se eliminar as inflorescências emitidas de março a junho, mantendo boa irrigação e adubação.

### 2.7.4. Manejo de perfilhos, limpeza das touceiras e controle do mato

#### 2.7.4.1. Controle do mato

Existem vários métodos: preventivo, manual, mecânico, físico (cobertura morta/viva) e químico (herbicidas). Recomenda-se o controle integrado. Nos primeiros anos, são necessárias 3 a 4 roçagens/ano. O uso de cobertura morta (serragem, casca de arroz) ou viva (leguminosas) é recomendado.

#### 2.7.4.2. Manejo de perfilhos

O excesso de perfilhos reduz o crescimento. É necessário o desbaste anual, mantendo no máximo quatro plantas por touceira (a mãe e três perfilhos em idades diferentes). Estipes muito altos devem ser eliminados e substituídos por um perfilho mais velho.

#### 2.7.4.3. Limpeza das touceiras

Consiste na retirada de folhas secas aderidas, o que favorece o crescimento do diâmetro dos estipes, diminui a presença de animais peçonhentos e facilita a colheita.

## 2.8. Sementes para cultivo

Podem ser usadas sementes de populações naturais (ecotipos) ou de programas de melhoramento.
- **Populações naturais:** Apresentam grande variação (açaí branco, roxo, açaí-açu, etc.), o que gera incerteza para o produtor.
- **Programas de melhoramento:** A cultivar BRS Pará, da Embrapa, é uma população melhorada com características como bom perfilhamento, precocidade e boa produção.

## 2.9. Espaçamentos indicados e consórcios

Para cultivo solteiro, os espaçamentos mais utilizados são 5m x 5m e 6m x 4m, com manejo de 3 a 4 estipes por touceira. Espaçamentos muito adensados não são recomendados. O cultivo consorciado com culturas alimentares ou fruteiras semiperenes ajuda a minimizar os custos iniciais. Um dos consórcios mais interessantes é com o cupuaçuzeiro.

## 2.10. Germinação

O processo é rápido, mas desuniforme, iniciando entre 17 e 28 dias e finalizando entre 33 e 60 dias após a semeadura. A porcentagem de germinação varia de 79% a 97,3%. A redução da umidade compromete a germinação.

## 2.11. Características do fruto e da polpa

O fruto é uma drupa globosa (1-2 cm de diâmetro, peso médio de 1,5 g). A parte comestível (epicarpo e mesocarpo) representa em média 26,54% do peso. A maior parte é o caroço (endocarpo).

## 2.12. Insetos-praga e doenças

A cultura é atacada por várias pragas e doenças, cujo conhecimento é determinante para o sucesso da produção.

### 2.12.1. Doenças

Microrganismos como fungos (antracnose, carvão, helmintosporiose) podem causar problemas, principalmente em viveiros. A antracnose é a mais frequente, podendo causar perdas de até 70% das mudas. O controle envolve bom manejo (adubação, ventilação) e, se necessário, fungicidas. Distúrbios fisiológicos como rachadura do estipe e deficiência de boro também são observados.

### 2.12.2. Insetos-praga

Ainda não há registros de perdas significativas por pragas, mas o aumento da área plantada exige monitoramento.

#### 2.12.2.1. Pulgão-preto-do-coqueiro ou afídeo-das-palmáceas

- **Danos:** Atraso no desenvolvimento de mudas, folhas amareladas, aparecimento de fumagina.
- **Controle:** Adotado quando 30-35% das plantas estão infestadas. Inseticidas botânicos são uma alternativa.

#### 2.12.2.2. Saúvas

- **Danos:** Corte dos folíolos, desfolhamento parcial ou total, podendo levar à morte das mudas.
- **Controle:** Eliminação dos sauveiros, uso de iscas granuladas e controle biológico.

#### 2.12.2.3. Moscas Brancas

- **Danos:** Sucção da seiva, amarelecimento, debilitação das plantas.
- **Controle:** Inspeções frequentes. Óleos minerais e inseticidas botânicos são alternativas.

#### 2.12.2.4. Gafanhotos

- **Danos:** Desfolhamento, atraso no desenvolvimento de plantas jovens.
- **Controle:** Difícil e oneroso. Táticas incluem catação manual, barreiras e uso de inseticidas biológicos.

#### 2.12.2.5. Cochonilha ou escama-vírgula

- **Danos:** Sucção da seiva, folhas amareladas, atraso no desenvolvimento.
- **Controle:** Inseticidas botânicos são uma alternativa promissora.

#### 2.12.2.6. Lagarta-desfolhadora

- **Danos:** Raspagem da epiderme e consumo da área foliar.
- **Controle:** Catação manual de imaturos no início da infestação.

## 2.13. Estimativas de produtividade

Os dados ainda são inconsistentes. A produção da planta-mãe começa no quarto ano e cresce a partir do sexto. Em um pomar, a produção atingiu 42,2 kg de frutos/touceira/ano no 11º ano. Em açaizais nativos manejados, a produtividade pode chegar a 9.000 kg/ha, contra 4.500 kg/ha em açaizais não manejados.

## 2.14. Cultivo do açaizeiro em terra firme

Representa uma excelente alternativa para recuperar áreas alteradas e reduz a pressão sobre o ecossistema de várzea. Facilita o transporte e o beneficiamento.

## 2.15. Custo do sistema de irrigação por microaspersão

O custo de uma lata de açaí irrigado é de R$ 13,78 (a 120 latas/ha), caindo para R$ 10,57/lata (a 180 latas/ha). O custo é vantajoso quando se aproveita o nicho de mercado da entressafra. Itens importantes de custo incluem combustível, transporte, energia elétrica e mão de obra.

## 2.16. Armazenamento das sementes

As sementes são recalcitrantes: perdem o poder germinativo com a secagem e não suportam temperaturas abaixo de 15 °C. Para armazenamento de curto prazo (até 20 dias), podem ser estratificadas em substrato úmido ou embaladas em sacos plásticos com umidade controlada. Pesquisas recentes indicam que a secagem parcial até 37,4% de umidade e armazenamento a 20 ºC podem conservar as sementes por até 240 dias.