import pandas as pd
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'knowledge/dados_meteorologicos/dados_meteorologicos_unidos.csv'
OUTPUT_DIR = 'knowledge/dados_meteorologicos'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'temperaturas_anuais_max_min.csv')

def calcular_temperaturas_max_min_anuais():
    """
    Lê os dados meteorológicos, encontra a temperatura máxima e mínima de cada ano,
    identifica o mês de ocorrência e salva o resultado em um novo CSV.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'unir_dados_meteorologicos.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE, sep=';')

    # --- Limpeza e Conversão de Dados ---
    print("Convertendo colunas para formato numérico e de data...")
    df['data_medicao'] = pd.to_datetime(df['data_medicao'], errors='coerce')
    df['temperatura_media_c'] = pd.to_numeric(df['temperatura_media_c'], errors='coerce')

    # Remove linhas onde a data ou a temperatura são inválidas
    df.dropna(subset=['data_medicao', 'temperatura_media_c'], inplace=True)

    df['Ano'] = df['data_medicao'].dt.year
    df['Mes'] = df['data_medicao'].dt.month

    # --- Encontrando Máximas e Mínimas ---
    print("Calculando temperaturas máximas e mínimas por ano...")

    # Encontra o índice da linha com a temperatura máxima para cada ano
    idx_max = df.groupby('Ano')['temperatura_media_c'].idxmax()
    df_max = df.loc[idx_max][['Ano', 'Mes', 'temperatura_media_c']].copy()
    df_max.rename(columns={
        'Mes': 'Mes_Maxima',
        'temperatura_media_c': 'Temperatura_Maxima_C'
    }, inplace=True)

    # Encontra o índice da linha com a temperatura mínima para cada ano
    idx_min = df.groupby('Ano')['temperatura_media_c'].idxmin()
    df_min = df.loc[idx_min][['Ano', 'Mes', 'temperatura_media_c']].copy()
    df_min.rename(columns={
        'Mes': 'Mes_Minima',
        'temperatura_media_c': 'Temperatura_Minima_C'
    }, inplace=True)

    # --- Unindo os Resultados ---
    print("Unindo os resultados...")
    df_final = pd.merge(df_max, df_min, on='Ano')

    # Mapeia o número do mês para o nome do mês para melhor legibilidade
    meses = {1: 'Jan', 2: 'Fev', 3: 'Mar', 4: 'Abr', 5: 'Mai', 6: 'Jun', 7: 'Jul', 8: 'Ago', 9: 'Set', 10: 'Out', 11: 'Nov', 12: 'Dez'}
    df_final['Mes_Maxima'] = df_final['Mes_Maxima'].map(meses)
    df_final['Mes_Minima'] = df_final['Mes_Minima'].map(meses)

    # --- Salvando o Resultado ---
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df_final.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig')

    print(f"\nArquivo '{os.path.basename(OUTPUT_FILE)}' salvo com sucesso em '{OUTPUT_FILE}'.")
    print("\nVisualização do resultado:")
    print(df_final.to_string(index=False))

if __name__ == '__main__':
    calcular_temperaturas_max_min_anuais()
