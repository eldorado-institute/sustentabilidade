import pandas as pd
import glob
import json
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_PATH = 'cleaned_data/*.json'
OUTPUT_DIR = 'knowledge/dados_prod_agricola'
FULL_OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'producao_agricola_medias.csv')
ACAI_OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'producao_agricola_media_acai.csv')

# Garante que o diretório de saída exista
os.makedirs(OUTPUT_DIR, exist_ok=True)

dados = []
for file in glob.glob(INPUT_PATH):
    with open(file, 'r', encoding='utf-8') as f:
        dados.extend(json.load(f))

df = pd.DataFrame(dados)


for col in ['V']:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# Calculo das médias por município/produto/variável
tabela = df.pivot_table(
    index=['D1N', 'D2N'],  # Município, Produto
    columns='D4N',         # Variável
    values='V',
    aggfunc='mean'
).reset_index()

# Adiciona somas para linhas "Total"
for var in ['Quantidade produzida', 'Rendimento médio da produção']:
    mask_total = tabela['D2N'] == 'Total'
    for municipio in tabela.loc[mask_total, 'D1N']:
        soma = df[(df['D1N'] == municipio) & (df['D2N'] != 'Total') & (df['D4N'] == var)]['V'].sum()
        tabela.loc[(tabela['D1N'] == municipio) & (tabela['D2N'] == 'Total'), var] = soma


tabela = tabela.rename(columns={'D1N': 'Municipio', 'D2N': 'Produto'})
tabela = tabela.fillna(0)
tabela = tabela.round(2)

# --- Formatação para o padrão brasileiro ---
# ATENÇÃO: Isso converte os números para texto (string).
print("Formatando dados da tabela completa para o padrão brasileiro...")
# Cria uma cópia para formatação, para não afetar o dataframe numérico original
tabela_full_formatada = tabela.copy()
numeric_cols_full = tabela_full_formatada.select_dtypes(include='number').columns
for col in numeric_cols_full:
    tabela_full_formatada[col] = tabela_full_formatada[col].apply(
        lambda x: f'{x:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
    )
# Salva o arquivo completo com as médias
tabela_full_formatada.to_csv(FULL_OUTPUT_FILE, index=False, encoding='utf-8-sig')

# Filtra para o Açaí, usando .copy() para evitar SettingWithCopyWarning
tabela_acai = tabela[tabela['Produto'] == 'Açaí'].copy()
tabela_acai = tabela_acai.drop(columns=['Área plantada'])

# --- AJUSTE SOLICITADO ---
# Ordena a tabela pela coluna 'Quantidade produzida' em ordem decrescente
# A ordenação deve ser feita nos dados numéricos, ANTES da formatação para string.
tabela_acai.sort_values(by='Quantidade produzida', ascending=False, inplace=True)

# Formata a tabela de açaí para o padrão brasileiro
numeric_cols_acai = tabela_acai.select_dtypes(include='number').columns
for col in numeric_cols_acai:
    tabela_acai[col] = tabela_acai[col].apply(
        lambda x: f'{x:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
    )
# Salva o arquivo final do Açaí
tabela_acai.to_csv(ACAI_OUTPUT_FILE, index=False, encoding='utf-8-sig')

print(f"Arquivo '{ACAI_OUTPUT_FILE}' gerado e ordenado com sucesso!")
