import pandas as pd
import glob
import io
import os

# --- Configuração ---
# Caminho para os arquivos de radiação
caminho_arquivos = 'data/dados-meteorologicos-INMET/radicao_global_INMET/*.csv'
# Caminhos para os arquivos de saída
output_dir = 'results/dados_radiacao_processados'
output_path_monthly = os.path.join(output_dir, 'radiacao_media_mensal.csv')
output_path_hourly = os.path.join(output_dir, 'radiacao_media_horaria_por_mes.csv')

# --- Processamento ---
arquivos = glob.glob(caminho_arquivos)
dfs = []

print(f"Encontrados {len(arquivos)} arquivos para processar.")

for arquivo in arquivos:
    print(f"Processando arquivo: {os.path.basename(arquivo)}...")
    try:
        # Tenta ler com 'latin-1', comum em fontes de dados brasileiras
        with open(arquivo, 'r', encoding='latin-1') as f:
            linhas = f.readlines()
    except Exception as e:
        print(f"  Erro ao ler o arquivo {arquivo}: {e}")
        continue

    # 1. Extrair metadados do cabeçalho
    contexto = {}
    for linha in linhas[:10]: # Limita a busca às 10 primeiras linhas
        if ':' in linha:
            try:
                chave, valor = linha.strip().split(':', 1)
                contexto[chave.strip()] = valor.strip()
            except ValueError:
                continue

    # 2. Encontrar o início dos dados
    idx_dados = None
    for i, linha in enumerate(linhas):
        if 'RADIACAO GLOBAL' in linha.upper():
            idx_dados = i
            break

    if idx_dados is None:
        print(f"  Aviso: Cabeçalho com 'RADIACAO GLOBAL' não encontrado em {arquivo}. Pulando.")
        continue

    # 3. Ler os dados em um DataFrame
    dados_csv_string = ''.join(linhas[idx_dados:])
    try:
        # Os arquivos do INMET geralmente usam ';' como separador.
        df = pd.read_csv(io.StringIO(dados_csv_string), sep=';', decimal=',')
        df.dropna(axis='columns', how='all', inplace=True)

        if len(df.columns) >= 3:
            df.columns = ['data_medicao', 'hora_medicao', 'radiacao_global'] + list(df.columns[3:])
        else:
            print(f"  Aviso: Número de colunas inesperado ({len(df.columns)}) no arquivo {arquivo}. Pulando.")
            continue

        df['estacao_nome'] = contexto.get('Nome', 'N/A')
        dfs.append(df)

    except Exception as e:
        print(f"  Erro ao processar os dados do arquivo {arquivo} com pandas: {e}")
        continue

if not dfs:
    print("Nenhum dado foi processado com sucesso. Encerrando.")
else:
    # 4. Concatenar, limpar e transformar os dados
    df_final = pd.concat(dfs, ignore_index=True)
    print(f"\nTotal de {len(df_final)} registros horários lidos de todos os arquivos.")

    df_final['data_medicao'] = pd.to_datetime(df_final['data_medicao'], errors='coerce')
    df_final['radiacao_global'] = pd.to_numeric(df_final['radiacao_global'], errors='coerce')
    df_final.dropna(subset=['data_medicao', 'radiacao_global', 'hora_medicao'], inplace=True)

    # Filtra apenas valores de radiação positivos (luz solar)
    df_final = df_final[df_final['radiacao_global'] > 0].copy()
    print(f"Restaram {len(df_final)} registros após filtrar radiação não-positiva.")

    df_final['ano'] = df_final['data_medicao'].dt.year
    df_final['mes'] = df_final['data_medicao'].dt.month
    df_final['hora'] = (df_final['hora_medicao'] // 100).astype(int)

    os.makedirs(output_dir, exist_ok=True)

    # --- GERAÇÃO DO ARQUIVO 1: MÉDIA MENSAL ---
    print(f"\nGerando arquivo de médias mensais em '{output_path_monthly}'...")
    media_mensal = df_final.groupby(['estacao_nome', 'ano', 'mes'])['radiacao_global'].mean().round(2).reset_index()
    media_mensal.rename(columns={'radiacao_global': 'radiacao_media_kj_m2'}, inplace=True)
    media_mensal.to_csv(output_path_monthly, index=False, sep=';', decimal='.')
    print(f"Arquivo de médias mensais gerado com {len(media_mensal)} linhas.")

    # --- GERAÇÃO DO ARQUIVO 2: MÉDIA HORÁRIA POR MÊS ---
    print(f"\nGerando arquivo de médias horárias por mês em '{output_path_hourly}'...")
    media_horaria_por_mes = df_final.groupby(['estacao_nome', 'mes', 'hora'])['radiacao_global'].mean().round(2)
    media_horaria_pivot = media_horaria_por_mes.unstack(level='hora').reset_index()
    media_horaria_pivot.columns = [f'hora_{col}' if isinstance(col, (int, float)) else col for col in media_horaria_pivot.columns]
    media_horaria_pivot.to_csv(output_path_hourly, index=False, sep=';', decimal='.')
    print(f"Arquivo de médias horárias gerado com {len(media_horaria_pivot)} linhas.")
