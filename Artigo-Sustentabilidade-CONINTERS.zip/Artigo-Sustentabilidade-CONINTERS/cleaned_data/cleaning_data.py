import json


def clean_temp_data(year: int):
    
    cleaned_data = []

    with open(f'../data/SIDRA/lav_temp_data_sidra_api_{year}.json', 'r', encoding='utf-8') as file:
        data = json.load(file)

    for item in data:
        if item['V'].isdigit() or item['V'] == 'Valor':
            cleaned_data.append(item)

    with open(f'cleaned_temp_data_sidra_api_{year}.json', 'w', encoding='utf-8') as file:
        json.dump(cleaned_data, file, ensure_ascii=False, indent=0)
        print(f'Salvado JSON limpo de lavoura temporária - {year}...')


def clean_perma_data(year: int):
    
    cleaned_data = []

    with open(f'../data/SIDRA/lav_perma_data_sidra_api_{year}.json', 'r', encoding='utf-8') as file:
        data = json.load(file)

    for item in data:
        if item['V'].isdigit() or item['V'] == 'Valor':
            cleaned_data.append(item)

    with open(f'cleaned_perma_data_sidra_api_{year}.json', 'w', encoding='utf-8') as file:
        json.dump(cleaned_data, file, ensure_ascii=False, indent=0)
        print(f'Salvado JSON limpo de lavoura permanente - {year}...')

for i in range(2014, 2024):
    clean_temp_data(i)
    clean_perma_data(i)