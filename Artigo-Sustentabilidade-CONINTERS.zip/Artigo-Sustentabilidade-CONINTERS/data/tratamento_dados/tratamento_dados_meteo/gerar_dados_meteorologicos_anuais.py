import pandas as pd
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE_METEO = 'knowledge/dados_meteorologicos/dados_meteorologicos_unidos.csv'
INPUT_FILE_RAD = 'results/dados_radiacao_processados/radiacao_media_anual.csv'
OUTPUT_DIR = 'knowledge/dados_meteorologicos'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'dados_meteorologicos_anuais_consolidados.csv')

def calcular_media_anual_meteorologica():
    """
    Lê os dados meteorológicos unidos, calcula as médias e totais anuais
    para todo o estado (agregando estações) e salva em um novo CSV.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE_METEO):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE_METEO}")
        print("Por favor, execute primeiro o script 'unir_dados_meteorologicos.py' para gerar o arquivo necessário.")
        return
    
    if not os.path.exists(INPUT_FILE_RAD):
        print(f"Arquivo de entrada de radiação não encontrado: {INPUT_FILE_RAD}")
        print("Por favor, execute primeiro o script 'gerar_dados_radiacao_anuais.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados meteorológicos de: {INPUT_FILE_METEO}")
    # O arquivo CSV usa ';' como separador
    df_meteo = pd.read_csv(INPUT_FILE_METEO, sep=';')
    print(f"Carregando dados de radiação de: {INPUT_FILE_RAD}")
    df_rad = pd.read_csv(INPUT_FILE_RAD)

    # --- Limpeza e Conversão de Dados ---
    print("Convertendo colunas para formato numérico e de data...")
    df_meteo['data_medicao'] = pd.to_datetime(df_meteo['data_medicao'], errors='coerce')
    df_meteo['Ano'] = df_meteo['data_medicao'].dt.year

    # Converte colunas para numérico, tratando valores não-numéricos como NaN
    numeric_cols = ['precipitacao_total_mm', 'dias_com_precipitacao', 'temperatura_media_c']
    for col in numeric_cols:
        df_meteo[col] = pd.to_numeric(df_meteo[col], errors='coerce')

    # Remove linhas onde o ano não pôde ser determinado
    df_meteo.dropna(subset=['Ano'], inplace=True)
    df_meteo['Ano'] = df_meteo['Ano'].astype(int)

    # --- Agregação dos Dados por Ano ---
    print("Agregando dados por ano para calcular médias e desvios padrão...")
    # Agrega os dados meteorológicos de todas as estações por ano.
    # - Calcula a média e o desvio padrão para cada métrica.
    df_anual = df_meteo.groupby('Ano').agg(
        Precipitacao_Media_Anual_mm=('precipitacao_total_mm', 'mean'),
        Precipitacao_Desvio_Padrao_mm=('precipitacao_total_mm', 'std'),
        Media_Dias_Chuva_Anual=('dias_com_precipitacao', 'mean'),
        Media_Dias_Chuva_Desvio_Padrao=('dias_com_precipitacao', 'std'),
        Temperatura_Media_Anual_C=('temperatura_media_c', 'mean'),
        Temperatura_Desvio_Padrao_C=('temperatura_media_c', 'std')
    ).reset_index()

    # Preenche valores NaN no desvio padrão (caso haja apenas uma medição no ano) com 0
    std_cols = [
        'Precipitacao_Desvio_Padrao_mm',
        'Media_Dias_Chuva_Desvio_Padrao',
        'Temperatura_Desvio_Padrao_C'
    ]
    df_anual[std_cols] = df_anual[std_cols].fillna(0)

    # Arredonda os resultados para 2 casas decimais
    df_anual = df_anual.round(2)

    # --- Unindo com os Dados de Radiação ---
    print("Unindo dados meteorológicos com dados de radiação...")
    df_anual = pd.merge(df_anual, df_rad, on='Ano', how='left')

    # Preenche valores de radiação ausentes (caso os anos não batam perfeitamente) com 0
    rad_cols_to_fill = ['Radiacao_Media_Anual_kj_m2', 'Radiacao_Desvio_Padrao_Anual_kj_m2']
    for col in rad_cols_to_fill:
        if col in df_anual.columns:
            df_anual[col] = df_anual[col].fillna(0)

    # --- Adicionar linha de Média Geral ---
    print("Calculando a média geral do período...")
    if not df_anual.empty:
        # Calcula a média de todas as colunas numéricas (exceto 'Ano')
        media_geral = df_anual.select_dtypes(include='number').mean().to_dict()
        media_geral['Ano'] = 'Média Geral'

        # Converte a coluna 'Ano' para objeto para poder adicionar a string
        df_anual['Ano'] = df_anual['Ano'].astype(str)

        # Adiciona a nova linha ao DataFrame
        df_anual.loc[len(df_anual)] = media_geral
        df_anual = df_anual.round(2)

    # --- Salvando o Resultado ---
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df_anual.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig', decimal='.')

    print(f"\nArquivo '{os.path.basename(OUTPUT_FILE)}' salvo com sucesso em '{OUTPUT_FILE}'.")
    print("\nVisualização do resultado:")
    print(df_anual.to_string(index=False))

if __name__ == '__main__':
    calcular_media_anual_meteorologica()
