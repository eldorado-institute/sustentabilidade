import json
from httpx import Client

def get_sidra_data_lav_perma(year: int):

    with Client() as client:
        response = client.get(f'https://apisidra.ibge.gov.br/values/t/1613/n6/in n3 13/c82/all/p/{year}/v/112,214,215,216,2313/f/n/h/y')
        response.raise_for_status()
        print(f'Adquirindo dados de lavoura permanente da SIDRA...{year}')

    
    with open(f'lav_perma_data_sidra_api_{year}.json','w', encoding='utf-8') as file:
        json.dump(response.json(), file, ensure_ascii=False, indent=0)
        print('Salvando dados json...')


def get_sidra_data_lav_temp(year: int):

    with Client() as client:
        response = client.get(f'https://apisidra.ibge.gov.br/values/t/1612/n6/in n3 13/c81/all/p/{year}/v/109,112,214,215,216/f/n/h/y')
        response.raise_for_status()
        print(f'Adquirindo dados de lavoura temporaria da SIDRA...{year}')

    
    with open(f'lav_temp_data_sidra_api_{year}.json','w', encoding='utf-8') as file:
        json.dump(response.json(), file, ensure_ascii=False, indent=0)
        print('Salvando dados json...')

for i in range(2014, 2024):
    get_sidra_data_lav_perma(i)
    get_sidra_data_lav_temp(i)