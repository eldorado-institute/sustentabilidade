import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio
import os

# --- Configuração de Caminhos ---
INPUT_FILE = 'results/dados_radiacao_processados/radiacao_media_anual.csv'

# Define o renderizador padrão para abrir no navegador
pio.renderers.default = 'browser'

def visualizar_radiacao_anual():
    """
    Cria um gráfico de LINHAS interativo da média anual de radiação solar.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'gerar_dados_radiacao_anuais.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)

    # --- Criação do Gráfico ---
    print("Gerando gráfico de linhas com Plotly...")
    fig = go.Figure()

    # Adiciona a linha de radiação média anual
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Radiacao_Media_Anual_kj_m2'],
        name='Radiação Média Anual',
        mode='lines+markers+text',
        line=dict(color='orange', width=2),
        marker=dict(size=8),
        text=df['Radiacao_Media_Anual_kj_m2'].round(2),
        textposition='top center'
    ))

    # --- Customização do Layout ---
    fig.update_layout(
        title={
            'text': '<b>Evolução da Radiação Solar Média Anual no Amazonas</b>',
            'y':0.9,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top'
        },
        xaxis_title='<b>Ano</b>',
        yaxis_title='<b>Radiação Média Anual (kJ/m²)</b>',
        xaxis=dict(tickmode='linear'),
        yaxis=dict(gridcolor='lightgray'),
        plot_bgcolor='white',
        font=dict(family="Arial, sans-serif", size=12, color="black")
    )

    # --- Exibição do Gráfico ---
    print("Exibindo gráfico interativo. Uma nova aba será aberta no seu navegador.")
    fig.show()

if __name__ == '__main__':
    visualizar_radiacao_anual()
