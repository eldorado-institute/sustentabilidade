from main import run_assistente_agronomia, run_assistente_meteorologia, run_assistente_sustentabilidade
import sys
import warnings

# Suprime avisos de depreciação para manter o output limpo
warnings.filterwarnings("ignore", category=DeprecationWarning)

__import__("pysqlite3")

sys.modules["sqlite3"] = sys.modules.pop("pysqlite3")

if __name__ == '__main__':
    run_assistente_sustentabilidade()