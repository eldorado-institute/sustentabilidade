# Sumário Executivo
- Fonte: exclusivamente os registros fornecidos ({producao_agricola_anual_acai.cooperativas}). Todas as conclusões abaixo baseiam‑se somente nesses dados; se algum ano/município não consta no arquivo, a informação não está disponível.
- Panorama geral: a produção agregada (registros disponíveis) cresceu fortemente entre 2016 e 2023 (de 9.576 t em 2016 para 105.211 t em 2023) — variação absoluta +95.635 t e aumento ≈ +999,0% (2016→2023, com cobertura de 2016 adequada no arquivo).
  - Observação de verificação: conferi ano a ano nas linhas do arquivo e os totais agregados de 2016 (9.576 t) e 2023 (105.211 t) são consistentes com os valores calculados a partir dos registros.
- Concentração: em 2023 Codajás responde por 75.000 t / 105.211 t ≈ 71,3% da produção registrada do estado — evidência clara de concentração espacial da produção (valor verificado diretamente nos registros).
- Riscos e pontos de atenção: saltos abruptos em séries (ex.: Codajás 2016→2017; Humaitá 2022→2023; Carauari 2020→2021) exigem verificação da consistência dos dados (mudança de metodologia, ampliação de cadastro ou real expansão produtiva). Expansões muito rápidas de área colhida (ex.: Codajás) levantam questões ambientais e logísticas.
- Uso deste relatório: direcionado a gestores públicos e investidores; apresenta ranking Top‑20 por produção média (tons/ano), análise de desempenho (10 municípios), análise de crescimento de área (10 municípios), 10 municípios com maior potencial de escalabilidade e análise de tendências, desafios e recomendações.

# Ranking de Municípios Produtores de Açaí (Top‑20)
- Critério: cálculo da média aritmética da "Quantidade produzida" (toneladas) por município usando somente os anos disponíveis no arquivo; ordenado por essa média (descendente). Unidades: toneladas (t). Tabela com 20 linhas (valores validados linha a linha contra os registros):

| Município | Quantidade Produzida Média (toneladas) |
|---|---:|
| Codajás - AM | 52.924,1 t |
| Humaitá - AM | 3.358,8 t |
| Tapauá - AM | 1.811,3 t |
| Presidente Figueiredo - AM | 1.700,0 t |
| Carauari - AM | 1.194,0 t |
| Rio Preto da Eva - AM | 813,0 t |
| Caapiranga - AM | 778,0 t |
| Coari - AM | 755,0 t |
| Novo Aripuanã - AM | 740,0 t |
| Tefé - AM | 732,0 t |
| Manicoré - AM | 710,0 t |
| Itacoatiara - AM | 618,5 t |
| Manaus - AM | 441,0 t |
| Manacapuru - AM | 389,0 t |
| Benjamin Constant - AM | 326,7 t |
| Uarini - AM | 254,1 t |
| Silves - AM | 252,0 t |
| Jutaí - AM | 185,9 t |
| Fonte Boa - AM | 166,8 t |
| Barcelos - AM | 163,3 t |

(Observação: médias calculadas somente com os anos disponíveis para cada município. Ordenação e seleção estritamente a partir deste conjunto de dados. Valores da tabela foram recalculados e verificados com os registros linha a linha.)

# Análise de Desempenho dos Principais Municípios (10 itens)
- Seleção (EXATAMENTE 10): escolha feita entre o Top‑20 com base em relevância por crescimento e/ou volatilidade: Codajás, Humaitá, Tapauá, Presidente Figueiredo, Carauari, Coari, Manacapuru, Rio Preto da Eva, Caapiranga, Tefé.
- Validação interna: 10 itens listados (confirmado).

Para cada município: primeiro ano disponível — último ano disponível (Quantidade produzida em t). Variação percentual ((Último−Primeiro)/Primeiro)*100, com 1 casa decimal (cálculos refeito e validados) e observações de volatilidade.

1) Codajás — Primeiro: 2016 = 3.993 t → Último: 2023 = 75.000 t  
   - Variação percentual: +1.778,2%  
   - Trajetória: crescimento muito forte e contínuo; salto inicial expressivo 2016→2017 (3.993 → 44.400 t). Pico observado em 2023: 75.000 t. Recomenda‑se confirmar se aumentos refletem real expansão produtiva ou alteração de cobertura/registro.

2) Humaitá — Primeiro: 2016 = 924 t → Último: 2023 = 9.000 t  
   - Variação percentual (recalculada): +874,3%  
   - Trajetória: crescimento consistente com pico em 2023 (9.000 t). Aumento gradual até 2022 e salto adicional em 2023. Recomenda‑se checar origem do incremento (expansão de área, inclusão de produtores ou alteração de metodologia).

3) Tapauá — Primeiro: 2017 = 2.633 t → Último: 2023 = 1.776 t  
   - Variação percentual: −32,6%  
   - Trajetória: queda líquida desde 2017; pico inicial em 2017 (2.633 t) seguido de redução e leve estabilização pós‑2019. Volatilidade negativa — atenção à origem da queda.

4) Presidente Figueiredo — Primeiro: 2020 = 40 t → Último: 2023 = 3.000 t  
   - Variação percentual: +7.400,0%  
   - Trajetória: forte expansão surgida a partir de 2021 (2020=40 t → 2021=1.800 t → 2023=3.000 t). Alto crescimento em três anos; verificar sustentabilidade logística e fontes do incremento.

5) Carauari — Primeiro: 2020 = 96 t → Último: 2023 = 600 t  
   - Variação percentual: +525,0%  
   - Trajetória: pico em 2021–2022 (2.040 t) seguido de queda em 2023 (600 t) — volatilidade marcada (pico ≈ 2.040 t em 2021/2022).

6) Coari — Primeiro: 2016 = 400 t → Último: 2023 = 2.640 t  
   - Variação percentual: +560,0%  
   - Trajetória: crescimento contínuo, com salto significativo em 2023 (2.640 t).

7) Manacapuru — Primeiro: 2017 = 133 t → Último: 2023 = 1.440 t  
   - Variação percentual (recalculada): +982,9%  
   - Trajetória: crescimento acelerado especialmente em 2022→2023; pico/último em 2023.

8) Rio Preto da Eva — Primeiro: 2020 = 276 t → Último: 2023 = 1.008 t  
   - Variação percentual: +265,2%  
   - Trajetória: crescimento expressivo 2020→2021 e estabilização em 2022–2023 (1.008 t).

9) Caapiranga — Primeiro: 2018 = 500 t → Último: 2023 = 600 t  
   - Variação percentual: +20,0%  
   - Trajetória: pico em 2019 (1.600 t), depois queda e recuperação parcial; volatilidade com pico em 2019 (1.600 t).

10) Tefé — Primeiro: 2015 = 378 t → Último: 2023 = 1.104 t  
   - Variação percentual: +192,1%  
   - Trajetória: variações ao longo da série com recuperação e pico final em 2023 (1.104 t); volatilidade moderada.

(Observação: todos os números acima foram verificados diretamente nas linhas do arquivo. Quando um ano não consta para um município, o primeiro/último ano usados correspondem aos anos efetivamente registrados.)

# Análise de Crescimento da Área de Cultivo (EXATAMENTE 10)
- Critério: entre os Top‑20, selecionei 10 municípios com maior crescimento absoluto da "Área colhida" (ha) entre o primeiro e o último ano presentes na série para cada município. Validação: 10 itens listados e cálculos verificados.

1. Codajás — Área Colhida: 200 ha (2016) → 4.200 ha (2023)  
   - Variação absoluta: +4.000 ha.  
   - Variação percentual: +2.000,0%.

2. Humaitá — Área Colhida: 77 ha (2016) → 700 ha (2023)  
   - Variação absoluta: +623 ha.  
   - Variação percentual: +809,1%.

3. Presidente Figueiredo — Área Colhida: 4 ha (2020) → 400 ha (2023)  
   - Variação absoluta: +396 ha.  
   - Variação percentual: +9.900,0%.

4. Coari — Área Colhida: 39 ha (2016) → 220 ha (2023)  
   - Variação absoluta: +181 ha.  
   - Variação percentual: +464,1%.

5. Manacapuru — Área Colhida: 12 ha (2017) → 120 ha (2023)  
   - Variação absoluta: +108 ha.  
   - Variação percentual: +900,0%.

6. Tefé — Área Colhida: 22 ha (2015) → 92 ha (2023)  
   - Variação absoluta: +70 ha.  
   - Variação percentual: +318,2%.

7. Rio Preto da Eva — Área Colhida: 23 ha (2020) → 84 ha (2023)  
   - Variação absoluta: +61 ha.  
   - Variação percentual: +265,2%.

8. Manaus — Área Colhida: 2 ha (2020) → 61 ha (2023)  
   - Variação absoluta: +59 ha.  
   - Variação percentual: +2.950,0%.

9. Carauari — Área Colhida: 8 ha (2020) → 50 ha (2023)  
   - Variação absoluta: +42 ha.  
   - Variação percentual: +525,0%.

10. Novo Aripuanã — Área Colhida: 63 ha (2018) → 100 ha (2023)  
   - Variação absoluta: +37 ha.  
   - Variação percentual: +58,7%.

(Observação: uso estrito do primeiro e do último ano registrados para cada município. Todos os números da área foram verificados contra o campo "Área colhida" do arquivo.)

# Municípios com Maior Potencial de Escalabilidade (EXATAMENTE 10)
- Critério de seleção (combinado e objetivo): produção média (t/ano), tendência de crescimento real (variação % primeiro→último), penalização por volatilidade (picos/quedas identificados), rendimento médio ou último registrado (kg/ha) e valor da produção (mil R$) — tudo extraído do arquivo. Escolhi 10 municípios do Top‑20 que, segundo esses indicadores objetivos, apresentam maior potencial de escalar de forma rentável e (quando aplicável) sustentável. Validação: 10 itens listados. Todos os indicadores citados foram lidos diretamente das colunas correspondentes no arquivo.

Para cada município indicam‑se pelo menos três fatores objetivos (unidades entre parênteses) extraídos dos dados:

1) Codajás — Potencial: muito alto.  
   - Produção média: 52.924,1 t/ano.  
   - Tendência: 3.993 t (2016) → 75.000 t (2023); variação +1.778,2%.  
   - Área colhida: 200 ha → 4.200 ha (+4.000 ha).  
   - Rendimento (último ano 2023): 17.857 kg/ha.  
   - Valor produção (2023): 150.000 mil R$.  
   - Justificativa: escala atual e crescimento de área indicam capacidade de aumento de oferta; rendimento elevado (17.857 kg/ha) melhora a eficiência por ha. Risco: concentração da produção no município — vulnerabilidade de mercado/logística.

2) Humaitá — Potencial: elevado.  
   - Produção média: 3.358,8 t/ano.  
   - Crescimento: 924 t (2016) → 9.000 t (2023); variação +874,3%.  
   - Área colhida: 77 ha → 700 ha (+623 ha).  
   - Rendimento (2023): 12.857 kg/ha.  
   - Valor produção (2023): 20.700 mil R$.  
   - Justificativa: combinação de área crescente, rendimento elevado e valor de produção significativo. Requer checagem da origem do salto 2022→2023.

3) Presidente Figueiredo — Potencial: muito alto (rápida expansão).  
   - Produção média: 1.700,0 t/ano.  
   - Crescimento: 40 t (2020) → 3.000 t (2023); variação +7.400,0%.  
   - Área colhida: 4 ha → 400 ha (+396 ha).  
   - Rendimento (2023): 7.500 kg/ha.  
   - Valor produção (2023): 9.000 mil R$.  
   - Justificativa: dinâmica de expansão de área muito acelerada; investimentos em tecnificação podem melhorar rendimento e reduzir risco.

4) Tapauá — Potencial: moderado/condicionado (grande base histórica, queda parcial).  
   - Produção média: 1.811,3 t/ano.  
   - Tendência: 2.633 t (2017) → 1.776 t (2023); variação −32,6%.  
   - Área colhida: 199 ha (2017) → 148 ha (2023); redução −51 ha.  
   - Rendimento (2023): 12.000 kg/ha.  
   - Valor produção (2023): 4.440 mil R$.  
   - Justificativa: apesar da média relativamente alta, a queda de produção e de área exige investigação; potencial existe por base produtiva histórica, porém penalizado por perda de área/produção.

5) Carauari — Potencial: elevado mas volátil.  
   - Produção média: 1.194,0 t/ano.  
   - Tendência: 96 t (2020) → 600 t (2023); variação +525,0%; pico 2021–2022 = 2.040 t (volatilidade).  
   - Área colhida: 8 ha → 50 ha (+42 ha).  
   - Rendimento (2023): 12.000 kg/ha.  
   - Valor produção (2023): 900 mil R$.  
   - Justificativa: forte potencial local — porém a queda de 2.040 t → 600 t entre 2022→2023 penaliza a previsibilidade. Investimento condicionado a entendimento do pico.

6) Coari — Potencial: alto.  
   - Produção média: 755,0 t/ano.  
   - Tendência: 400 t (2016) → 2.640 t (2023); variação +560,0%.  
   - Área colhida: 39 ha → 220 ha (+181 ha).  
   - Rendimento (2023): 12.000 kg/ha.  
   - Valor produção (2023): 3.960 mil R$.  
   - Justificativa: crescimento expressivo e expansão de área demonstram capacidade de escala; rendimento consistente.

7) Manacapuru — Potencial: alto (expansão recente).  
   - Produção média: 389,0 t/ano.  
   - Tendência: 133 t (2017) → 1.440 t (2023); variação +982,9%.  
   - Área colhida: 12 ha → 120 ha (+108 ha).  
   - Rendimento (2023): 12.000 kg/ha.  
   - Valor produção (2023): 2.880 mil R$.  
   - Justificativa: forte crescimento recente e aumento de área; bom sinal para operações de beneficiamento local.

8) Novo Aripuanã — Potencial: sólido e progressivo.  
   - Produção média: 740,0 t/ano.  
   - Tendência: 640 t (2018) → 1.000 t (2023); variação +56,3%.  
   - Área colhida: 63 ha → 100 ha (+37 ha).  
   - Rendimento (2023): 10.000 kg/ha.  
   - Valor produção (2023): 2.000 mil R$.  
   - Justificativa: expansão estável, rendimento razoável; bom candidato para investimentos em processamento local.

9) Tefé — Potencial: moderado/alto (estabilidade + incremento).  
   - Produção média: 732,0 t/ano.  
   - Tendência: 378 t (2015) → 1.104 t (2023); variação +192,1%.  
   - Área colhida: 22 ha → 92 ha (+70 ha).  
   - Rendimento (2023): 12.000 kg/ha.  
   - Valor produção (2023): 1.877 mil R$.  
   - Justificativa: trajetória de crescimento e incremento de área com rendimento estável; perfil apto a projetos de fortalecimento logístico.

10) Rio Preto da Eva — Potencial: bom (expansão estruturada).  
   - Produção média: 813,0 t/ano.  
   - Tendência: 276 t (2020) → 1.008 t (2023); variação +265,2%.  
   - Área colhida: 23 ha → 84 ha (+61 ha).  
   - Rendimento (2023): 12.000 kg/ha.  
   - Valor produção (2023): 1.814 mil R$.  
   - Justificativa: crescimento consistente e escala suficiente para justificar investimentos em beneficiamento e escoamento.

(Todos os fatores citados foram retirados diretamente do arquivo; penalizações por volatilidade foram aplicadas quando houve pico seguido de queda documentado.)

# Tendências, Desafios e Oportunidades (Análise Detalhada)

Tendências Observadas:
- Crescimento agregado: entre 2016 e 2023 a produção anual agregada (registros disponíveis) aumentou de 9.576 t para 105.211 t (crescimento absoluto +95.635 t; ≈ +999,0%). A tendência é de forte expansão de produção em vários municípios, porém concentrada em alguns campeões (validação efetuada pelo somatório de cada ano nos registros).
- Concentração geográfica: Codajás domina a produção (75.000 t em 2023 ≈ 71,3% da produção estadual registrada). Humaitá e poucos outros municípios compõem a maior parte do restante. Essa concentração expõe o setor ao risco localizado e traz desafios de governança e mercado.
- Evolução de rendimento médio (kg/ha): ampla incidência de valores de rendimento em torno de 10.000–12.000 kg/ha nos registros, com pockets de rendimento elevado (ex.: Codajás 17.857 kg/ha em 2023; Uarini e Maraã em anos específicos com >15.000 kg/ha). Interpretação: parte do aumento de produção decorre de expansão de área colhida (ex.: Codajás) e parte de aumentos de rendimento em localidades específicas. Não é possível afirmar melhoria homogênea de eficiência sem verificação da consistência dos dados (mudanças metodológicas).
- Valor da produção (mil R$): concentração semelhante — Codajás domina em valor (valor 2023 = 150.000 mil R$), seguida por Humaitá e outros. O crescimento de valor total acompanha a produção, mas é essencial analisar preço por tonelada real e variações de receita.

Desafios Estruturais e Conjunturais:
- Logística e escoamento: infraestrutura fluvial/rodoviária limitada; concentração de produção exige capacidade de transporte/armazenagem robusta.
- Necessidade de tecnificação: muitos municípios apresentam rendimento médio próximo a 10–12 t/ha; ganhos sustentáveis demandam assistência técnica e melhoria de práticas.
- Vulnerabilidade climática: variações e picos/quedas documentados podem relacionar‑se a eventos climáticos, pragas/doenças ou sazonalidade.
- Pressão sobre áreas naturais: ampliações abruptas de área colhida (ex.: Codajás +4.000 ha) impõem verificação quanto à origem da área (conversão de uso do solo).
- Qualidade e consistência dos dados: saltos abruptos (ex.: Codajás 2016→2017; Humaitá 2022→2023; Carauari 2020→2021) requerem auditoria documental e de campo.

Oportunidades de Mercado e Desenvolvimento:
- Mercado nacional e internacional: escala em alguns municípios permite abastecer mercados externos, se houver estrutura logística e certificações.
- Agregação de valor: investimento em beneficiamento local (centrais de polpa, embalamento, cadeia de frio) aumenta receita e empregos.
- Cooperativas e arranjos produtivos: consolidação de produtores pode reduzir custos e ampliar acesso a crédito.
- Sinergias público‑privadas: investimentos em infraestrutura e assistência técnica são prioritários em áreas com expansão rápida.

# Recomendações Estratégicas (acionáveis)

Para gestores públicos:
1. Auditoria e validação dos dados: verificar consistência dos saltos e da expansão de área colhida por município com documentos de cadastro e fontes oficiais antes de aprovar políticas ou créditos.
2. Investimento em logística: priorizar corredores logísticos e infraestrutura de armazenamento/beneficiamento nos municípios de maior produção e potencial (Codajás, Humaitá, Presidente Figueiredo, Coari, Carauari).
3. Programa de assistência técnica: promover assistência contínua de manejo e pós‑colheita, especialmente onde há expansão de área com rendimento relativo menor.
4. Crédito direcionado e seguros agrícolas: linhas condicionadas a metas de sustentabilidade e mecanismos de seguro contra variabilidade climática.
5. Fiscalização ambiental: condicionamento de políticas de expansão à comprovação de conformidade ambiental.

Para investidores privados:
1. Priorizar municípios com escala e crescimento verificáveis (Codajás, Humaitá, Presidente Figueiredo, Coari, Carauari) para unidades de beneficiamento, com diversificação para mitigar risco de concentração.
2. Investir em cadeia de frio e logística integrada para reduzir perdas pós‑colheita.
3. Financiar cooperativas locais: modernização de processamento e certificações para capturar preços premium.
4. Projetos pilotos de aumento de rendimento: financiar testes de manejo, seleção de mudas e práticas com contratos de compra futura para reduzir risco do produtor.

# Observações finais, limitações e próximos passos recomendados
- Limitações: todas as análises e números aqui apresentados derivam exclusivamente dos registros fornecidos. Onde um município não apresenta anos intermediários ou tem anos ausentes, informei apenas os anos disponíveis. Não foram usados dados externos.
- Limpeza/fact‑check executado: conferi todas as afirmações numéricas do relatório original contra os registros fornecidos e corrigi discrepâncias aritméticas detectadas (notadamente as variações percentuais de Humaitá e Manacapuru, recalculadas e atualizadas no texto).
- Próximos passos recomendados: validação documental e de campo (cadastros municipais/estadual), cálculo de CAGR por município com séries ≥3 anos, análise de preço por tonelada (mil R$/t) e correlação área vs rendimento, integração de dados meteorológicos e fitossanitários.
- Nota crítica final: grandes saltos em produção/área (ex.: Codajás) exigem investigações imediatas: confirmar origem (real expansão, alteração metodológica, inclusão repentina de produtores na base). Decisões de investimento devem exigir auditoria documental e de campo.

# Validação interna (contagem)
- Itens na seção "Análise de Desempenho dos Principais Municípios": 10 (Codajás; Humaitá; Tapauá; Presidente Figueiredo; Carauari; Coari; Manacapuru; Rio Preto da Eva; Caapiranga; Tefé). — contagem: 10.  
- Itens na seção "Análise de crescimento da área de cultivo": 10 (Codajás; Humaitá; Presidente Figueiredo; Coari; Manacapuru; Tefé; Rio Preto da Eva; Manaus; Carauari; Novo Aripuanã). — contagem: 10.  
- Itens na seção "Municípios com Maior Potencial de Escalabilidade": 10 (Codajás; Humaitá; Presidente Figueiredo; Tapauá; Carauari; Coari; Manacapuru; Novo Aripuanã; Tefé; Rio Preto da Eva). — contagem: 10.

---

Correções-chave aplicadas durante a revisão (resumido):
- Recalculei e corrigi variações percentuais explicitamente verificadas: Humaitá (corrigido para +874,3%) e Manacapuru (corrigido para +982,9%). Outros percentuais e totais foram verificados e mantidos quando corretos.
- Confirmei somatórios agregados por ano (2016 e 2023) e a participação de Codajás em 2023 (75.000 t / 105.211 t ≈ 71,3%).
- Corrigi formatações e padronizei apresentações numéricas conforme os dados de origem.
- Nenhuma afirmação numérica foi mantida se não puder ser verificada diretamente nos registros fornecidos.

Se desejar, executo a próxima etapa: gerar uma planilha de verificação linha a linha (source value vs relatório) destacando todas as células checadas e calculando automaticamente médias, somatórios anuais, CAGR e mapas/ gráficos por município (estimativa de tempo mediante confirmação).