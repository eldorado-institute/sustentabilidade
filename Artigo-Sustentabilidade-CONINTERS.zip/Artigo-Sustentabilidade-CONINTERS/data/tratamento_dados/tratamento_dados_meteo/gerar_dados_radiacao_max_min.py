import pandas as pd
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'results/dados_radiacao_processados/radiacao_media_mensal.csv'
OUTPUT_DIR = 'results/dados_radiacao_processados'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'radiacao_anual_max_min.csv')

def calcular_radiacao_max_min_anuais():
    """
    Lê os dados de radiação média mensal, encontra a radiação máxima e mínima de cada ano,
    identifica o mês e a estação de ocorrência e salva o resultado em um novo CSV.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'dados_radiacao.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE, sep=';')

    # --- Limpeza e Conversão de Dados ---
    print("Convertendo colunas para formato numérico...")
    df['ano'] = pd.to_numeric(df['ano'], errors='coerce')
    df['radiacao_media_kj_m2'] = pd.to_numeric(df['radiacao_media_kj_m2'], errors='coerce')

    # Remove linhas onde o ano ou a radiação são inválidas
    df.dropna(subset=['ano', 'radiacao_media_kj_m2'], inplace=True)
    df['ano'] = df['ano'].astype(int)

    # --- Encontrando Máximas e Mínimas ---
    print("Calculando radiação máxima e mínima por ano...")

    # Encontra o índice da linha com a radiação máxima para cada ano
    idx_max = df.groupby('ano')['radiacao_media_kj_m2'].idxmax()
    df_max = df.loc[idx_max][['ano', 'mes', 'radiacao_media_kj_m2', 'estacao_nome']].copy()
    df_max.rename(columns={
        'ano': 'Ano',
        'mes': 'Mes_Maxima',
        'radiacao_media_kj_m2': 'Radiacao_Maxima_kj_m2',
        'estacao_nome': 'Estacao_Maxima'
    }, inplace=True)

    # Encontra o índice da linha com a radiação mínima para cada ano
    idx_min = df.groupby('ano')['radiacao_media_kj_m2'].idxmin()
    df_min = df.loc[idx_min][['ano', 'mes', 'radiacao_media_kj_m2', 'estacao_nome']].copy()
    df_min.rename(columns={
        'ano': 'Ano',
        'mes': 'Mes_Minima',
        'radiacao_media_kj_m2': 'Radiacao_Minima_kj_m2',
        'estacao_nome': 'Estacao_Minima'
    }, inplace=True)

    # --- Unindo os Resultados ---
    print("Unindo os resultados...")
    df_final = pd.merge(df_max, df_min, on='Ano')

    # Mapeia o número do mês para o nome do mês para melhor legibilidade
    meses = {1: 'Jan', 2: 'Fev', 3: 'Mar', 4: 'Abr', 5: 'Mai', 6: 'Jun', 7: 'Jul', 8: 'Ago', 9: 'Set', 10: 'Out', 11: 'Nov', 12: 'Dez'}
    df_final['Mes_Maxima'] = df_final['Mes_Maxima'].map(meses)
    df_final['Mes_Minima'] = df_final['Mes_Minima'].map(meses)

    # Remove as colunas de estação, pois a análise é agregada por ano e elas não são mais necessárias no output final
    df_final = df_final.drop(columns=['Estacao_Maxima', 'Estacao_Minima'])

    # --- Salvando o Resultado ---
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df_final.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig')

    print(f"\nArquivo '{os.path.basename(OUTPUT_FILE)}' salvo com sucesso em '{OUTPUT_FILE}'.")
    print("\nVisualização do resultado:")
    print(df_final.to_string(index=False))

if __name__ == '__main__':
    calcular_radiacao_max_min_anuais()
