from crewai import Agent, Crew, Process, Task, LLM
from crewai.project import CrewBase, agent, crew, task


llm_data_analysis = LLM(model='gpt-4o', temperature=0.5)
llm_generate_report = LLM(model='gpt-4o-mini', temperature=0.5)
llm_gpt_5_mini = LLM(model='gpt-5-mini', temperature=1)
llm_synthesis = LLM(model='gpt-4o', temperature=0.5)
# llm_web_scrapping = LLM(model='gpt-4o-mini')


@CrewBase
class AgronomiaCrew:
    agents_config = 'config/agents_agro.yaml'
    tasks_config = 'config/tasks_agro.yaml'

    @agent
    def especialista_agronomia(self) -> Agent:
        return Agent(
            config=self.agents_config["especialista_agronomia"], # type: ignore
            verbose=True,
            llm=llm_gpt_5_mini,
        )

    @agent
    def agente_revisor(self) -> Agent:
        return Agent(
            config=self.agents_config["agente_revisor"], # type: ignore
            verbose=True,
            llm=llm_gpt_5_mini,
        )
    
    @task
    def analise_producao_anual_acai(self) -> Task:
        return Task(
            config=self.tasks_config["analise_producao_anual_acai"], # type: ignore
            agent=self.especialista_agronomia()
        )

    @task
    def gerar_relatorio_agronomico(self) -> Task:
        return Task(
            config=self.tasks_config["gerar_relatorio_agronomico"], # type: ignore
            agent=self.especialista_agronomia(),
            context=[self.analise_producao_anual_acai()]
        )
    
    @task
    def validar_relatorio_agronomico(self) -> Task:
        return Task(
            config=self.tasks_config["validar_relatorio_agronomico"], # type: ignore
            agent=self.agente_revisor(),
            context=[self.gerar_relatorio_agronomico()]
        )
    
    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=[self.especialista_agronomia(), self.agente_revisor()],
            tasks=[self.analise_producao_anual_acai(), self.gerar_relatorio_agronomico(), self.validar_relatorio_agronomico()],
            process=Process.sequential,
            verbose=True,
        )


@CrewBase
class HidrologicCrew:
    agents_config = 'config/agents_hidro.yaml'
    tasks_config = 'config/tasks_hidro.yaml'

    @agent
    def especialista_hidrologia(self) -> Agent:
        return Agent(
            config=self.agents_config["especialista_hidrologia"], # type: ignore
            verbose=True,
            llm=llm_data_analysis,
            allow_delegation=False,
        )

    @agent
    def analista_hidrologico_chefe(self) -> Agent:
        return Agent(
            config=self.agents_config["analista_hidrologico_chefe"], # type: ignore
            verbose=True,
            llm=llm_generate_report,
        )
    

    @task
    def analise_parcial_hidrologica(self) -> Task:
        return Task(
            config=self.tasks_config["analise_parcial_hidrologica"], # type: ignore
            agent=self.especialista_hidrologia()
        )
    
    @task
    def consolidar_analise_hidrologica(self) -> Task:
        return Task(
            config=self.tasks_config["consolidar_analise_hidrologica"], # type: ignore
            agent=self.analista_hidrologico_chefe()
        )


@CrewBase
class MeteorologiaCrew:
    agents_config = 'config/agents_meteo.yaml'
    tasks_config = 'config/tasks_meteo.yaml'

    @agent
    def especialista_climatologia(self) -> Agent:
        return Agent(
            config=self.agents_config["especialista_climatologia"], # type: ignore
            verbose=True,
            llm=llm_gpt_5_mini,
        )

    @task
    def analise_parcial_dados_meteorologicos(self) -> Task:
        return Task(
            config=self.tasks_config["analise_parcial_dados_meteorologicos"], # type: ignore
            agent=self.especialista_climatologia()
        )

    @agent
    def analista_climatologico_chefe(self) -> Agent:
        return Agent(
            config=self.agents_config["analista_climatologico_chefe"], # type: ignore
            verbose=True,
            llm=llm_gpt_5_mini,
        )

    @task
    def consolidar_analise_climatologica(self) -> Task:
        return Task(
            config=self.tasks_config["consolidar_analise_climatologica"], # type: ignore
            agent=self.analista_climatologico_chefe()
        )
    
    @agent
    def especialista_radiacao_solar(self) -> Agent:
        return Agent(
            config=self.agents_config["especialista_radiacao_solar"], # type: ignore
            verbose=True,
            llm=llm_gpt_5_mini,
        )

    @task
    def analise_dados_radiacao(self) -> Task:
        return Task(
            config=self.tasks_config["analise_dados_radiacao"], # type: ignore
            agent=self.especialista_radiacao_solar()
        )    

# @CrewBase
# class WebScrapperCrew:
#     agents_config = 'config/agents_web_scrapping.yaml'
#     tasks_config = 'config/tasks_web_scrapping.yaml'

#     @agent
#     def web_scrapper_acai_botanica(self) -> Agent:
#         return Agent(
#             config=self.agents_config["web_scrapper_acai_botanica"], # type: ignore
#             verbose=False,
#             llm=llm_web_scrapping,
#         )

#     @task
#     def listagem_links_acai_botanica(self) -> Task:
#         return Task(
#             config=self.tasks_config["listagem_links_acai_botanica"], # type: ignore
#             agent=self.web_scrapper_acai_botanica(),
#         )


@CrewBase
class SustainabilityCrew:
    """
    Um crew para analisar a sustentabilidade da cadeia produtiva do açaí, integrando dados agronômicos, de cultivo, meteorológicos e artigos científicos.
    """
    agents_config = 'config/agents_sustainability.yaml'
    tasks_config = 'config/tasks_sustainability.yaml'

    @agent
    def especialista_sustentabilidade(self) -> Agent:
        return Agent(
            config=self.agents_config["especialista_sustentabilidade"], # type: ignore
            verbose=True,
            llm=llm_gpt_5_mini,
        )

    @task
    def analise_dados_agronomicos(self) -> Task:
        return Task(
            config=self.tasks_config["analise_dados_agronomicos"], # type: ignore
            agent=self.especialista_sustentabilidade()
        )

    @task
    def analise_guia_cultivo(self) -> Task:
        return Task(
            config=self.tasks_config["analise_guia_cultivo"], # type: ignore
            agent=self.especialista_sustentabilidade()
        )

    @task
    def analise_dados_meteorologicos(self) -> Task:
        return Task(
            config=self.tasks_config["analise_dados_meteorologicos"], # type: ignore
            agent=self.especialista_sustentabilidade()
        )

    @task
    def analise_artigos_sustentabilidade(self) -> Task:
        return Task(
            config=self.tasks_config["analise_artigos_sustentabilidade"], # type: ignore
            agent=self.especialista_sustentabilidade()
        )

    @task
    def gerar_panorama_sustentabilidade_acai(self) -> Task:
        return Task(
            config=self.tasks_config["gerar_panorama_sustentabilidade_acai"], # type: ignore
            agent=self.especialista_sustentabilidade()
        )

    @crew
    def crew(self) -> Crew:
        # A orquestração agora é feita em main.py para controlar o tamanho dos inputs.
        # Este método de crew sequencial não é mais o ponto de entrada principal para esta tarefa.
        raise NotImplementedError("A orquestração da análise de sustentabilidade foi movida para main.py para controle de contexto.")
