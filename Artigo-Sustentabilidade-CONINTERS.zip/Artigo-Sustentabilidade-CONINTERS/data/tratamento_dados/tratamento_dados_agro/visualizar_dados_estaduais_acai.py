import pandas as pd
import plotly.graph_objects as go
import plotly.io as pio
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'knowledge/dados_prod_agricola/producao_estadual_anual_acai.csv'

# --- Configuração do Plotly ---
# Define o renderizador padrão como 'browser' para garantir que o gráfico
# seja aberto em uma nova aba do navegador, evitando o erro de 'nbformat'.
# Isso é especialmente útil ao executar o script fora de um ambiente Jupyter.
pio.renderers.default = 'browser'

def visualizar_producao_estadual():
    """
    Cria um gráfico de LINHA interativo da produção estadual anual de açaí
    com barras de erro para o desvio padrão, usando Plotly.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'gerar_dados_estaduais_acai.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)

    # --- Criação do Gráfico ---
    print("Gerando gráfico de linha com Plotly...")
    fig = go.Figure()

    # Adiciona a linha de produção total
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Producao_Total_Estado_toneladas'],
        name='Produção Total (toneladas)',
        mode='lines+markers',  # Define o tipo de gráfico como linha com marcadores
        line=dict(color='darkgreen', width=2),
        marker=dict(color='darkgreen', size=8),
        # Adiciona as barras de erro usando a coluna de desvio padrão
        error_y=dict(
            type='data', # tipo de barra de erro
            array=df['Desvio_Padrao_Producao_toneladas'],
            visible=True,
            thickness=1.5,
            width=3,
            color='gray'
        ),
        text=df['Producao_Total_Estado_toneladas'].apply(lambda x: f'{x:,.0f}'.replace(',', '.')),
        textposition='top center'
    ))

    # --- Customização do Layout ---
    fig.update_layout(
        title={
            'text': '<b>Evolução da Produção Anual de Açaí no Amazonas (2015-2023)</b>',
            'y':0.9,
            'x':0.5,
            'xanchor': 'center',
            'yanchor': 'top'
        },
        xaxis_title='<b>Ano</b>',
        yaxis_title='<b>Produção Total (toneladas)</b>',
        xaxis=dict(
            tickmode='linear' # Garante que todos os anos sejam mostrados
        ),
        yaxis=dict(
            gridcolor='lightgray'
        ),
        plot_bgcolor='white',
        font=dict(
            family="Arial, sans-serif",
            size=12,
            color="black"
        ),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )

    # --- Exibição do Gráfico ---
    print("Exibindo gráfico interativo. Uma nova aba será aberta no seu navegador.")
    fig.show()

if __name__ == '__main__':
    # Nota: Para executar este script, você precisa ter o Plotly instalado.
    # Execute no terminal: pip install plotly kaleido
    visualizar_producao_estadual()
