import pandas as pd
import base64
import io
import os
import re
import pypdfium2 as pdfium

from pdf2image import convert_from_path
from crewai import Crew, Process
from crew import AgronomiaCrew, MeteorologiaCrew, SustainabilityCrew


def pil_images_to_base64_messages(images: list, max_dimension: int = 1024):
    """
    Converte uma lista de objetos PIL.Image em uma lista de mensagens de imagem em base64,
    redimensionando-as para um tamanho máximo para controlar o uso de tokens.
    """
    messages = []
    for image in images:
        # Redimensiona a imagem se ela for maior que a dimensão máxima, mantendo a proporção.
        if image.width > max_dimension or image.height > max_dimension:
            image.thumbnail((max_dimension, max_dimension))

        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        b64 = base64.b64encode(buffer.getvalue()).decode("utf-8")
        messages.append({"type": "image_url", "image_url": f"data:image/png;base64,{b64}"})
    return messages


def extrair_texto_pdf_e_limpar(pdf_path: str) -> str:
    """
    Extrai o texto de um arquivo PDF, removendo as seções de Agradecimentos e Referências.
    """
    pdf = None
    try:
        texto_completo = ""
        pdf = pdfium.PdfDocument(pdf_path)
        for page in pdf:
            texto_completo += page.get_textpage().get_text_range() + "\n"

        # Encontra o início da primeira seção a ser removida (Agradecimentos ou Referências)
        # A busca é case-insensitive e considera variações no início da linha.
        limite_match = re.search(r'^\s*(agradecimentos|refer[êe]ncias bibliográficas|refer[êe]ncias)', texto_completo, re.IGNORECASE | re.MULTILINE)

        texto_limpo = texto_completo
        if limite_match:
            texto_limpo = texto_completo[:limite_match.start()]
        
        texto_limpo = texto_limpo.strip()

        print(f"Texto extraído e limpo do PDF. Tamanho original: {len(texto_completo)} chars, Tamanho limpo: {len(texto_limpo)} chars.")
        return texto_limpo
    except Exception as e:
        print(f"Erro ao extrair texto do PDF {pdf_path}: {e}")
        return f"Erro ao processar o PDF: {e}. Verifique se a biblioteca pypdfium2 está instalada e se o arquivo PDF não está corrompido."
    finally:
        if pdf:
            pdf.close()


def run_assistente_agronomia():
    # Carrega os dados do CSV para uma string
    path_media = 'knowledge/dados_prod_agricola/producao_agricola_media_acai.csv'
    path_anual = 'knowledge/dados_prod_agricola/producao_agricola_anual_acai.csv'
    try:
        df_media = pd.read_csv(path_media)
        dados_media_string = df_media.to_string()

        df_anual = pd.read_csv(path_anual)
        dados_anual_string = df_anual.to_string()
    except FileNotFoundError:
        print(f"Um ou ambos os arquivos CSV não foram encontrados: {path_media}, {path_anual}")
        return

    # Inicializa o Crew de Agronomia
    crew_instance = AgronomiaCrew()

    # Define os inputs para o kickoff, passando os dados do CSV
    inputs = {
        'producao_agricola_media_acai': dados_media_string,
        'producao_agricola_anual_acai': dados_anual_string
    }

    # Roda o Assistente de Agronomia, passando os inputs
    resultado = crew_instance.crew().kickoff(inputs=inputs)
    _save_and_print_results(resultado, 'results/relatorio_agronomico_v32.md')
    return resultado


# def run_assistente_hidrologia(chunk_size=1, dpi=75):
#     """
#     Executa o assistente de hidrologia com um processo de duas etapas:
#     1. Análise parcial de chunks de imagens de cada PDF.
#     2. Consolidação das análises parciais em um relatório final comparativo.
#     """
#     crew_instance = HidrologicCrew()

#     # Agentes e Tarefas
#     especialista = crew_instance.especialista_hidrologia()
#     analista_chefe = crew_instance.analista_hidrologico_chefe()
#     task_parcial = crew_instance.analise_parcial_hidrologica()
#     task_consolidacao = crew_instance.consolidar_analise_hidrologica()

#     pdfs = [
#         "knowledge/dados_fluviometricos/serie_historica_rio_negro.pdf",
#         "knowledge/dados_fluviometricos/serie_historica_rio_solimoes.pdf"
#     ]

#     resumos_parciais = []
#     print("--- Iniciando Etapa 1: Análise Parcial dos Documentos ---")

#     for pdf_path in pdfs:
#         try:
#             # Converte o PDF para imagens uma única vez para otimizar o processo
#             all_pages = convert_from_path(pdf_path, dpi=dpi)
#             num_pages = len(all_pages)
#             nome_rio = os.path.basename(pdf_path).replace('.pdf', '').replace('serie_historica_', '')
#             print(f"\n📄 Processando {num_pages} páginas do PDF: {nome_rio}")

#             if num_pages == 0:
#                 print(f"Aviso: PDF '{pdf_path}' não contém páginas ou não pôde ser lido.")
#                 continue

#             for i in range(0, num_pages, chunk_size):
#                 start_page = i
#                 end_page = min(i + chunk_size, num_pages)
#                 print(f"  🔹 Analisando chunk: Páginas {start_page + 1}-{end_page}")
                
#                 # Seleciona o chunk de imagens já convertidas e as codifica em base64
#                 chunk_images = all_pages[start_page:end_page]
#                 chunk_messages = pil_images_to_base64_messages(chunk_images, max_dimension=1024)

#                 if not chunk_messages:
#                     print(f"  Aviso: Nenhuma imagem gerada para o chunk de páginas {start_page + 1}-{end_page}.")
#                     continue

#                 # Crew para este chunk específico
#                 crew_parcial = Crew(
#                     agents=[especialista],
#                     tasks=[task_parcial],
#                     verbose=True
#                 )

#                 # Executa o crew para o chunk
#                 resultado_chunk = crew_parcial.kickoff(inputs={
#                     'nome_rio': nome_rio,
#                     'chunk_imagens_hidrologicas': chunk_messages
#                 })
#                 resumos_parciais.append(str(resultado_chunk))
#                 print(f"  --- Análise do chunk finalizada. ---\n")

#         except Exception as e:
#             print(f"Erro ao processar o PDF {pdf_path}: {e}")
#             continue

#     if not resumos_parciais:
#         print("Nenhuma análise parcial foi gerada. Abortando a etapa de consolidação.")
#         return

#     # Etapa 2: Consolidação
#     print("\n--- Iniciando Etapa 2: Consolidação do Relatório Final ---")
#     contexto_consolidado = "\n\n---\n\n".join(resumos_parciais)

#     # Crew final para consolidação
#     crew_final = Crew(
#         agents=[analista_chefe],
#         tasks=[task_consolidacao],
#         process=Process.sequential,
#         verbose=True
#     )

#     # Executa a consolidação
#     resultado_final = crew_final.kickoff(inputs={'resumos_parciais': contexto_consolidado})

#     _save_and_print_results(resultado_final, 'results/relatorio_hidrologia_consolidado.md')
#     return resultado_final


def run_assistente_meteorologia():
    """Executa o assistente de análise meteorológica em chunks por estação para evitar limites de token."""
    # --- CAMINHOS PARA OS DADOS ---
    path_precip_temp = 'knowledge/dados_meteorologicos/dados_meteorologicos_compilados.txt'
    path_rad_mensal = 'results/dados_radiacao_processados/radiacao_media_mensal.csv'
    path_rad_horaria = 'results/dados_radiacao_processados/radiacao_media_horaria_por_mes.csv'

    # --- ETAPA 1: Análise de Precipitação e Temperatura (como antes) ---
    print("--- Iniciando Etapa 1: Análise de Precipitação e Temperatura ---")
    try:
        with open(path_precip_temp, 'r', encoding='utf-8') as f:
            # Lê o conteúdo e divide em blocos por estação
            content = f.read()
            station_blocks = content.split('\n---\n\n')
    except FileNotFoundError:
        print(f"Arquivo de dados meteorológicos não encontrado: {path_precip_temp}")
        return

    # Inicializa o Crew de Meteorologia
    crew_instance = MeteorologiaCrew()

    # Agentes para a Etapa 1
    especialista = crew_instance.especialista_climatologia()

    # Executa as tarefas parciais sequencialmente e coleta os resultados
    resumos_parciais = []
    num_chunks = len(station_blocks)
    print(f"Analisando dados de {num_chunks} estações (chunks).")

    for i, block in enumerate(station_blocks):
        if not block.strip():  # Ignora blocos vazios (ex: do final do arquivo)
            continue

        print(f"\n--- Processando Estação (Chunk) {i + 1}/{num_chunks} ---")

        # A tarefa de análise parcial
        task_parcial = crew_instance.analise_parcial_dados_meteorologicos()

        # Crew para este chunk específico
        crew_parcial = Crew(
            agents=[especialista],
            tasks=[task_parcial],
            verbose=True
        )

        # Executa o crew para o chunk (bloco da estação)
        resultado_chunk = crew_parcial.kickoff(inputs={'chunk_dados_meteorologicos': block})
        resumos_parciais.append(str(resultado_chunk))
        print(f"--- Estação (Chunk) {i + 1} finalizada. ---\n")

    # --- ETAPA 2: Análise de Radiação Solar ---
    print("\n--- Iniciando Etapa 2: Análise de Radiação Solar ---")
    try:
        # Alterado de .to_string() para .to_csv() para uma representação mais compacta e reduzir tokens.
        # O método .to_string() gera uma saída muito verbosa, que excede o limite de tokens.
        dados_rad_mensal_str = pd.read_csv(path_rad_mensal, sep=';').to_csv(index=False)
        dados_rad_horaria_str = pd.read_csv(path_rad_horaria, sep=';').to_csv(index=False)
    except FileNotFoundError:
        print(f"Arquivos de dados de radiação não encontrados. Pulando etapa 2.")
        dados_rad_mensal_str = "Dados não disponíveis."
        dados_rad_horaria_str = "Dados não disponíveis."

    # Agente e Tarefa para a Etapa 2
    agente_radiacao = crew_instance.especialista_radiacao_solar()
    task_radiacao = crew_instance.analise_dados_radiacao()

    crew_radiacao = Crew(
        agents=[agente_radiacao],
        tasks=[task_radiacao],
        verbose=True
    )

    resumo_radiacao = crew_radiacao.kickoff(inputs={
        'dados_radiacao_mensal': dados_rad_mensal_str,
        'dados_radiacao_horaria': dados_rad_horaria_str
    })
    print("--- Análise de Radiação Solar finalizada. ---\n")

    # --- ETAPA 3: Consolidação Final ---
    print("\n--- Iniciando Etapa 3: Consolidação do Relatório Final ---")
    contexto_consolidado = "\n\n---\n\n".join(resumos_parciais)

    # Agente e Tarefa para a Etapa 3
    analista_chefe = crew_instance.analista_climatologico_chefe()
    task_consolidacao = crew_instance.consolidar_analise_climatologica()

    # Crew final para consolidação
    crew_final = Crew(
        agents=[analista_chefe],
        tasks=[task_consolidacao],
        process=Process.sequential,
        verbose=True
    )

    # Executa a consolidação
    resultado_final = crew_final.kickoff(inputs={
        'resumos_parciais': contexto_consolidado,
        # Converte o objeto CrewOutput para string para que possa ser interpolado corretamente.
        'resumo_radiacao': str(resumo_radiacao)
    })

    _save_and_print_results(resultado_final, 'results/relatorio_meteorologico_v1.md')
    return resultado_final


def run_assistente_sustentabilidade():
    """
    Executa o assistente de sustentabilidade em um processo de múltiplas etapas
    para gerar um panorama completo e projeções futuras para a cadeia do açaí.
    """
    print("\n--- INICIANDO O ASSISTENTE DE SUSTENTABILIDADE (PROCESSO MULTI-ETAPAS) ---")
    
    # Instancia o Crew que servirá como fábrica de agentes e tarefas
    crew_instance = SustainabilityCrew()
    agent = crew_instance.especialista_sustentabilidade()
    
    # --- Definição dos Caminhos dos Arquivos ---
    # Etapa 1: Agronomia
    path_prod_media_acai = 'arquivos_finais/agronomia/producao_agricola_media_acai.csv'
    path_prod_anual_acai = 'arquivos_finais/agronomia/producao_estadual_anual_acai.csv'
    # path_relatorio_agronomico = 'arquivos_finais/agronomia/relatorio_agronomico_v_final.md'

    # Etapa 2: Cultivo
    path_guia_cultivo_acai = 'arquivos_finais/cultivo/guia_cultivo_acai.md'

    # Etapa 3: Meteorologia
    path_meteo_medias_anuais = 'arquivos_finais/meteorologia/dados_meteorologicos_medias_anuais.csv'
    path_rad_media_anual = 'arquivos_finais/meteorologia/radiacao_media_anual.csv'
    path_temp_anuais_max_min = 'arquivos_finais/meteorologia/temperaturas_anuais_max_min.csv'
    # path_relatorio_meteo = 'arquivos_finais/meteorologia/relatorio_meteorologico_v_final.md'

    # Etapa 4: Artigo de Sustentabilidade
    path_artigo_sustentabilidade_ambiental = 'arquivos_finais/artigos/Artigo-Sustentabilidade-Ambiental.pdf'
    path_artigo_sustentabilidade_economica = 'arquivos_finais/artigos/Artigo-Sustentabilidade-Economica.pdf'

    try:
        # --- ETAPA 1: Análise Agronômica (Map) ---
        print("\n--- Etapa 1: Análise Agronômica ---")
        task_agro = crew_instance.analise_dados_agronomicos()
        crew_agro = Crew(agents=[agent], tasks=[task_agro], verbose=True)
        inputs_agro = {
            'producao_agricola_media_acai': pd.read_csv(path_prod_media_acai).to_string(),
            'producao_estadual_anual_acai': pd.read_csv(path_prod_anual_acai).to_string()
        }
        # with open(path_relatorio_agronomico, 'r', encoding='utf-8') as f:
        #     inputs_agro['relatorio_agronomico_v_final'] = f.read()
        resumo_agronomico = crew_agro.kickoff(inputs=inputs_agro)

        # --- ETAPA 2: Análise de Cultivo (Map) ---
        print("\n--- Etapa 2: Análise do Guia de Cultivo ---")
        task_cultivo = crew_instance.analise_guia_cultivo()
        crew_cultivo = Crew(agents=[agent], tasks=[task_cultivo], verbose=True)
        inputs_cultivo = {}
        with open(path_guia_cultivo_acai, 'r', encoding='utf-8') as f:
            inputs_cultivo['guia_cultivo_acai'] = f.read()
        resumo_cultivo = crew_cultivo.kickoff(inputs=inputs_cultivo)

        # --- ETAPA 3: Análise Meteorológica (Map) ---
        print("\n--- Etapa 3: Análise Meteorológica ---")
        task_meteo = crew_instance.analise_dados_meteorologicos()
        crew_meteo = Crew(agents=[agent], tasks=[task_meteo], verbose=True)
        inputs_meteo = {
            'dados_meteorologicos_medias_anuais': pd.read_csv(path_meteo_medias_anuais).to_string(),
            'radiacao_media_anual': pd.read_csv(path_rad_media_anual).to_string(),
            'temperaturas_anuais_max_min': pd.read_csv(path_temp_anuais_max_min).to_string()
        }
        # with open(path_relatorio_meteo, 'r', encoding='utf-8') as f:
        #     inputs_meteo['relatorio_meteorologico_v_final'] = f.read()
        resumo_meteorologico = crew_meteo.kickoff(inputs=inputs_meteo)

        # --- ETAPA 4: Análise do Artigo (Map) ---
        print("\n--- Etapa 4: Análise do Artigo de Sustentabilidade ---")
        task_sust = crew_instance.analise_artigos_sustentabilidade()
        crew_sust = Crew(agents=[agent], tasks=[task_sust], verbose=True)

        print(f"Processando PDF ambiental para extração de texto: {path_artigo_sustentabilidade_ambiental}")
        texto_artigo_ambiental = extrair_texto_pdf_e_limpar(path_artigo_sustentabilidade_ambiental)

        print(f"Processando PDF econômico para extração de texto: {path_artigo_sustentabilidade_economica}")
        texto_artigo_economico = extrair_texto_pdf_e_limpar(path_artigo_sustentabilidade_economica)

        inputs_sust = {
            'artigo_sustentabilidade_ambiental_texto': texto_artigo_ambiental,
            'artigo_sustentabilidade_economica_texto': texto_artigo_economico
        }
        print(f"Textos dos artigos extraídos. Enviando para análise...")
        resumo_artigos_sustentabilidade = crew_sust.kickoff(inputs=inputs_sust)

    except FileNotFoundError as e:
        print(f"\nErro: Não foi possível encontrar um dos arquivos necessários: {e}")
        print("Verifique se as pastas /agronomia, /cultivo, /meteorologia e /artigos existem e contêm os arquivos corretos.")
        return
    except Exception as e:
        print(f"\nOcorreu um erro inesperado durante a execução de uma das etapas: {e}")
        return

    # --- ETAPA FINAL: Síntese (Reduce) ---
    print("\n--- Etapa Final: Geração do Panorama de Sustentabilidade ---")
    task_sintese = crew_instance.gerar_panorama_sustentabilidade_acai()
    crew_sintese = Crew(agents=[agent], tasks=[task_sintese], verbose=True)
    
    synthesis_inputs = {
        'resumo_agronomico': str(resumo_agronomico),
        'resumo_cultivo': str(resumo_cultivo),
        'resumo_meteorologico': str(resumo_meteorologico),
        'resumo_artigos_sustentabilidade': str(resumo_artigos_sustentabilidade),
    }
    
    resultado_final = crew_sintese.kickoff(inputs=synthesis_inputs)

    _save_and_print_results(resultado_final, 'results/relatorio_sustentabilidade_acai_sem_contexto.md')
    print("--- FIM DO ASSISTENTE DE SUSTENTABILIDADE ---")
    return resultado_final


def _get_unique_filename(output_path: str) -> str:
    """
    Verifica se o caminho do arquivo já existe. Se sim, anexa um número
    sequencial para criar um nome de arquivo único.
    Ex: 'path/file.md' -> 'path/file_2.md'
    """
    if not os.path.exists(output_path):
        return output_path

    directory, filename = os.path.split(output_path)
    name, ext = os.path.splitext(filename)
    
    counter = 2
    while True:
        new_filename = f"{name}_{counter}{ext}"
        new_path = os.path.join(directory, new_filename)
        if not os.path.exists(new_path):
            return new_path
        counter += 1


def _save_and_print_results(resultado, output_path: str):
    """Salva o resultado em um arquivo com nome único e imprime o uso de tokens."""
    if hasattr(resultado, "token_usage"):
        print(f"Tokens utilizados: {resultado.token_usage}")
    else:
        print("Atributo 'token_usage' não encontrado no resultado.")

    final_path = _get_unique_filename(output_path)
    os.makedirs(os.path.dirname(final_path), exist_ok=True)

    with open(final_path, 'w', encoding='utf-8') as file:
        file.write(str(resultado))
    print(f"Resultado salvo em: {final_path}")
