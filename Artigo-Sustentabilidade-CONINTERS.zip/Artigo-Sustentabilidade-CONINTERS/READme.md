# Artigo-Sustentabilidade-CONINTERS: Análise Integrada da Cadeia do Açaí no Amazonas

## Visão Geral do Projeto

Este projeto tem como objetivo realizar uma análise multifacetada e integrada da cadeia produtiva do açaí no estado do Amazonas, com foco na sustentabilidade. Utilizando um framework de agentes de IA (`crewAI`), o sistema processa e correlaciona dados de diversas fontes: agronômicos, meteorológicos, guias de cultivo e artigos científicos. Para gerar relatórios estratégicos e insights acionáveis. O objetivo final é fornecer um panorama completo dos desafios, oportunidades e projeções futuras para a cadeia do açaí, auxiliando na tomada de decisões para gestores públicos, investidores e produtores.

## Funcionalidades Principais

O projeto é estruturado em torno de "assistentes" especializados, cada um responsável por uma área de análise:

*   **Assistente de Agronomia:** Analisa dados de produção agrícola (quantidade, rendimento, valor, área colhida) para identificar tendências, municípios de destaque e potencial de escalabilidade.
*   **Assistente de Meteorologia:** Processa dados climáticos (precipitação, temperatura, radiação solar) para identificar padrões sazonais, eventos extremos e tendências históricas, culminando em cenários climáticos futuros.
*   **Assistente de Sustentabilidade:** Integra as análises agronômicas e meteorológicas com informações de guias de cultivo e artigos científicos sobre sustentabilidade ambiental e econômica, gerando um panorama estratégico completo da cadeia do açaí.

## Estrutura do Projeto

*   `main.py`: Contém as funções principais para a execução dos assistentes e utilitários de processamento de imagens e PDFs.
*   `crew.py` (assumido): Define as classes `AgronomiaCrew`, `MeteorologiaCrew`, `SustainabilityCrew`, que orquestram os agentes e tarefas de cada assistente.
*   `knowledge/`: Diretório que armazena os dados brutos de entrada (CSV, TXT, PDF) para as análises.
*   `arquivos_finais/`: Diretório com dados pré-processados ou relatórios intermediários que servem como entrada para o assistente de sustentabilidade.
*   `config/`: Contém arquivos de configuração (YAML) que definem as tarefas e agentes para cada assistente.
*   `results/`: Diretório onde os relatórios e resultados gerados pelos assistentes são salvos.
*   `data/tratamento_dados/tratamento_dados_meteo/`: Contém scripts para tratamento e visualização de dados meteorológicos.

## Pré-requisitos

Para executar este projeto, você precisará ter instalado:

*   **Python 3.8+**
*   **Bibliotecas Python:**
    *   `pandas`
    *   `crewai`
    *   `pypdfium2`
    *   `pdf2image`
    *   `Pillow` (geralmente instalada como dependência de `pdf2image`)
    *   `python-dotenv` (se usado para gerenciar chaves de API, embora não explícito no `main.py`)
    *   `re` (módulo padrão do Python)
    *   `io` (módulo padrão do Python)
    *   `base64` (módulo padrão do Python)
    *   `os` (módulo padrão do Python)
*   **Dependências externas para `pdf2image`:**
    *   `poppler`: A biblioteca `pdf2image` requer `poppler` para converter PDFs em imagens. Certifique-se de que `poppler` esteja instalado em seu sistema operacional e acessível via PATH.

Você pode instalar as bibliotecas Python via pip:

```bash
pip install pandas crewai pypdfium2 pdf2image Pillow
