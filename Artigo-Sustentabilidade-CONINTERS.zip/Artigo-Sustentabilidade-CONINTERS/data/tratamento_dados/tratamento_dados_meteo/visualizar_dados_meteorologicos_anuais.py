import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.io as pio
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'knowledge/dados_meteorologicos/dados_meteorologicos_anuais_consolidados.csv'

# Define o renderizador padrão para abrir no navegador
pio.renderers.default = 'browser'

def visualizar_temperatura_anual(df: pd.DataFrame):
    """
    Cria um gráfico de linha interativo com os dados anuais de temperatura.
    """
    print("\nGerando gráfico de Temperatura Anual...")
    fig = go.Figure()

    # Adiciona a linha de Temperatura Média (eixo primário)
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Temperatura_Media_Anual_C'],
        name='Temperatura Média (°C)',
        mode='lines+markers',
        line=dict(color='crimson'),
    ))

    fig.update_layout(
        title={'text': '<b>Evolução da Temperatura Média Anual no Amazonas</b>', 'y':0.9, 'x':0.5, 'xanchor': 'center', 'yanchor': 'top'},
        xaxis_title='<b>Ano</b>',
        yaxis_title='<b>Temperatura Média Anual (°C)</b>',
        plot_bgcolor='white',
        font=dict(family="Arial, sans-serif", size=12, color="black"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    fig.update_xaxes(tickmode='linear', gridcolor='lightgray', linecolor='black')
    fig.update_yaxes(gridcolor='lightgray', linecolor='black')

    print("Exibindo gráfico de temperatura. Uma nova aba será aberta no seu navegador.")
    fig.show()

def visualizar_precipitacao_anual(df: pd.DataFrame):
    """
    Cria um gráfico de linha interativo com os dados anuais de precipitação.
    """
    print("\nGerando gráfico de Precipitação Anual...")
    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Adiciona a linha de Precipitação Média Mensal (eixo secundário)
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Precipitacao_Media_Anual_mm'],
        name='Precipitação Média Mensal (mm)',
        mode='lines+markers',
        line=dict(color='blue'),
    ), secondary_y=True)

    # Adiciona a linha de Média de Dias com Chuva (eixo primário)
    fig.add_trace(go.Scatter(
        x=df['Ano'],
        y=df['Media_Dias_Chuva_Anual'],
        name='Média de Dias com Chuva',
        mode='lines+markers',
        line=dict(color='green', dash='dot'),
    ), secondary_y=False)

    fig.update_layout(
        title={'text': '<b>Evolução Anual da Precipitação no Amazonas</b>', 'y':0.9, 'x':0.5, 'xanchor': 'center', 'yanchor': 'top'},
        xaxis_title='<b>Ano</b>',
        plot_bgcolor='white',
        font=dict(family="Arial, sans-serif", size=12, color="black"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )

    fig.update_yaxes(title_text="<b>Média de Dias com Chuva</b>", secondary_y=False, gridcolor='lightgray', linecolor='black')
    fig.update_yaxes(title_text="<b>Precipitação Média Mensal (mm)</b>", secondary_y=True, showgrid=False, linecolor='black')

    fig.update_xaxes(tickmode='linear', gridcolor='lightgray', linecolor='black')

    print("Exibindo gráfico de precipitação. Uma nova aba será aberta no seu navegador.")
    fig.show()

def main():
    """
    Carrega os dados e gera as visualizações meteorológicas anuais.
    """
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'gerar_dados_meteorologicos_anuais.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)

    visualizar_temperatura_anual(df)
    visualizar_precipitacao_anual(df)

if __name__ == '__main__':
    main()
