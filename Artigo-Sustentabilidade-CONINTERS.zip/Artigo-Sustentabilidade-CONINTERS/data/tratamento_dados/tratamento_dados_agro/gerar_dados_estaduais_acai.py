import pandas as pd
import os

# --- Configuração de Caminhos ---
# Assumindo que o script é executado da raiz do projeto
INPUT_FILE = 'data/tratamento_dados/tratamento_dados_agro/producao_agricola_anual_acai.csv'
OUTPUT_DIR = 'knowledge/dados_prod_agricola'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'producao_estadual_anual_acai.csv')

def calcular_producao_estadual_anual():
    """
    Calcula a produção total e o desvio padrão da produção de açaí
    para o estado do Amazonas, por ano, e salva o resultado em um novo CSV.
    """
    # --- Verificação do Arquivo de Entrada ---
    if not os.path.exists(INPUT_FILE):
        print(f"Arquivo de entrada não encontrado: {INPUT_FILE}")
        print("Por favor, execute primeiro o script 'gerar_dados_anuais_acai.py' para gerar o arquivo necessário.")
        return

    print(f"Carregando dados de: {INPUT_FILE}")
    df = pd.read_csv(INPUT_FILE)

    # --- Limpeza e Conversão de Dados ---
    # A coluna 'Quantidade produzida' está formatada como string no padrão brasileiro (ex: "1.234,56").
    # É necessário convertê-la para um formato numérico para os cálculos.
    print("Convertendo a coluna 'Quantidade produzida' para formato numérico...")
    
    def converter_para_float(valor_str):
        """Remove o separador de milhar '.' e substitui o separador decimal ',' por '.'."""
        try:
            return float(str(valor_str).replace('.', '').replace(',', '.'))
        except (ValueError, TypeError):
            return 0.0

    df['Quantidade produzida'] = df['Quantidade produzida'].apply(converter_para_float)

    # --- Agregação dos Dados por Ano ---
    print("Agregando dados por ano para calcular a produção total e o desvio padrão...")
    df_estadual = df.groupby('Ano')['Quantidade produzida'].agg(['sum', 'std']).reset_index()

    # Renomeia as colunas para maior clareza
    df_estadual.rename(columns={
        'sum': 'Producao_Total_Estado_toneladas',
        'std': 'Desvio_Padrao_Producao_toneladas'
    }, inplace=True)

    df_estadual['Desvio_Padrao_Producao_toneladas'] = df_estadual['Desvio_Padrao_Producao_toneladas'].fillna(0)
    df_estadual = df_estadual.round(2)

    # --- Salvando o Resultado ---
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    df_estadual.to_csv(OUTPUT_FILE, index=False, encoding='utf-8-sig')

    print(f"\nArquivo '{os.path.basename(OUTPUT_FILE)}' salvo com sucesso em '{OUTPUT_FILE}'.")
    print("\nVisualização do resultado:")
    print(df_estadual.to_string(index=False))

if __name__ == '__main__':
    calcular_producao_estadual_anual()
